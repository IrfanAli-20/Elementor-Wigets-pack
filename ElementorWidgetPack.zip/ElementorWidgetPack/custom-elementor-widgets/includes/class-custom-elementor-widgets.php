<?php
/**
 * Custom Elementor Widgets main class
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Main plugin class
 */
class Custom_Elementor_Widgets {

    /**
     * Constructor
     *
     * @access public
     */
    public function __construct() {
        // Register styles and scripts
        add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_frontend_scripts' ] );
        add_action( 'elementor/frontend/after_register_styles', [ $this, 'register_frontend_styles' ] );
        
        // Register widgets
        add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
        
        // Register widget categories
        add_action( 'elementor/elements/categories_registered', [ $this, 'register_widget_categories' ] );
    }

    /**
     * Register frontend scripts
     *
     * @access public
     */
    public function register_frontend_scripts() {
        wp_register_script(
            'custom-elementor-widgets',
            CUSTOM_ELEMENTOR_WIDGETS_URL . 'assets/js/custom-elementor-widgets.js',
            [ 'jquery', 'elementor-frontend' ],
            CUSTOM_ELEMENTOR_WIDGETS_VERSION,
            true
        );
    }

    /**
     * Register frontend styles
     *
     * @access public
     */
    public function register_frontend_styles() {
        wp_register_style(
            'custom-elementor-widgets',
            CUSTOM_ELEMENTOR_WIDGETS_URL . 'assets/css/custom-elementor-widgets.css',
            [],
            CUSTOM_ELEMENTOR_WIDGETS_VERSION
        );
    }

    /**
     * Register widget categories
     *
     * @access public
     * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
     */
    public function register_widget_categories( $elements_manager ) {
        $elements_manager->add_category(
            'custom-elementor-widgets',
            [
                'title' => __( 'Custom Elementor Widgets', 'custom-elementor-widgets' ),
                'icon' => 'fa fa-plug',
            ]
        );
    }

    /**
     * Register widgets
     *
     * @access public
     * @return void
     */
    public function register_widgets() {
        // Require all widget files
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-posts-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-forms-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-call-to-action-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-slides-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-advanced-post-grid-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-creative-buttons-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-interactive-testimonials-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-info-box-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-modal-popup-widget.php';
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'widgets/class-jet-tabs-widget.php';

        // Register widgets
        \Elementor\Plugin::instance()->widgets_manager->register( new Posts_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Forms_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Call_To_Action_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Slides_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Advanced_Post_Grid_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Creative_Buttons_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Interactive_Testimonials_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Info_Box_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Modal_Popup_Widget() );
        \Elementor\Plugin::instance()->widgets_manager->register( new Jet_Tabs_Widget() );
    }
}
