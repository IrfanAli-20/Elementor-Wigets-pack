<?php
/**
 * Plugin Name: Custom Elementor Widgets
 * Description: A custom WordPress plugin that bundles 10 key Elementor widgets.
 * Version: 1.0.0
 * Author: Custom Developer
 * Author URI: https://example.com
 * Text Domain: custom-elementor-widgets
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Elementor tested up to: 3.19
 * 
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define plugin constants.
define( 'CUSTOM_ELEMENTOR_WIDGETS_VERSION', '1.0.0' );
define( 'CUSTOM_ELEMENTOR_WIDGETS_FILE', __FILE__ );
define( 'CUSTOM_ELEMENTOR_WIDGETS_DIR', plugin_dir_path( __FILE__ ) );
define( 'CUSTOM_ELEMENTOR_WIDGETS_URL', plugins_url( '/', __FILE__ ) );

/**
 * Main Plugin Class
 */
final class Custom_Elementor_Widgets_Plugin {

    /**
     * Instance
     *
     * @access private
     * @static
     * @var Custom_Elementor_Widgets_Plugin The single instance of the class.
     */
    private static $_instance = null;

    /**
     * Instance
     *
     * Ensures only one instance of the class is loaded or can be loaded.
     *
     * @access public
     * @static
     * @return Custom_Elementor_Widgets_Plugin An instance of the class.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     *
     * @access public
     */
    public function __construct() {
        // Include required files
        $this->includes();
        
        // Initialize the plugin
        add_action( 'plugins_loaded', [ $this, 'init' ] );
    }

    /**
     * Include required files
     *
     * @access private
     */
    private function includes() {
        // Include main plugin class
        require_once CUSTOM_ELEMENTOR_WIDGETS_DIR . 'includes/class-custom-elementor-widgets.php';
    }

    /**
     * Initialize the plugin
     *
     * @access public
     */
    public function init() {
        // Check if Elementor is installed and activated
        if ( ! did_action( 'elementor/loaded' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_missing_elementor' ] );
            return;
        }

        // Check Elementor version
        if ( ! version_compare( ELEMENTOR_VERSION, '3.0.0', '>=' ) ) {
            add_action( 'admin_notices', [ $this, 'admin_notice_elementor_version' ] );
            return;
        }

        // Initialize the main plugin class
        new Custom_Elementor_Widgets();
    }

    /**
     * Admin notice for missing Elementor
     *
     * @access public
     */
    public function admin_notice_missing_elementor() {
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }

        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor */
            esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'custom-elementor-widgets' ),
            '<strong>' . esc_html__( 'Custom Elementor Widgets', 'custom-elementor-widgets' ) . '</strong>',
            '<strong>' . esc_html__( 'Elementor', 'custom-elementor-widgets' ) . '</strong>'
        );

        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }

    /**
     * Admin notice for minimum Elementor version
     *
     * @access public
     */
    public function admin_notice_elementor_version() {
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }

        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
            esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'custom-elementor-widgets' ),
            '<strong>' . esc_html__( 'Custom Elementor Widgets', 'custom-elementor-widgets' ) . '</strong>',
            '<strong>' . esc_html__( 'Elementor', 'custom-elementor-widgets' ) . '</strong>',
            '3.0.0'
        );

        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }
}

// Initialize the plugin
Custom_Elementor_Widgets_Plugin::instance();
