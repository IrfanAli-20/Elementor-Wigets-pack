<?php
/**
 * Interactive Testimonials Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Interactive Testimonials Widget Class
 */
class Interactive_Testimonials_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_interactive_testimonials';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Interactive Testimonials', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-testimonial-carousel';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'testimonial', 'review', 'feedback', 'interactive', 'carousel' ];
    }

    /**
     * Register widget scripts.
     */
    public function get_script_depends() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget styles.
     */
    public function get_style_depends() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Testimonials Section
        $this->start_controls_section(
            'section_testimonials',
            [
                'label' => __( 'Testimonials', 'custom-elementor-widgets' ),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'name',
            [
                'label' => __( 'Name', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'John Doe', 'custom-elementor-widgets' ),
                'placeholder' => __( 'Enter name', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'position',
            [
                'label' => __( 'Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'CEO', 'custom-elementor-widgets' ),
                'placeholder' => __( 'Enter position', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'company',
            [
                'label' => __( 'Company', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Company Name', 'custom-elementor-widgets' ),
                'placeholder' => __( 'Enter company', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'content',
            [
                'label' => __( 'Content', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'custom-elementor-widgets' ),
                'placeholder' => __( 'Enter testimonial content', 'custom-elementor-widgets' ),
                'rows' => 10,
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label' => __( 'Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'rating',
            [
                'label' => __( 'Rating', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '5',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                ],
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => __( 'Link', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'custom-elementor-widgets' ),
                'default' => [
                    'url' => '',
                ],
                'show_external' => true,
            ]
        );

        $this->add_control(
            'testimonials',
            [
                'label' => __( 'Testimonials', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'name' => __( 'John Doe', 'custom-elementor-widgets' ),
                        'position' => __( 'CEO', 'custom-elementor-widgets' ),
                        'company' => __( 'Company Name', 'custom-elementor-widgets' ),
                        'content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'custom-elementor-widgets' ),
                        'rating' => '5',
                    ],
                    [
                        'name' => __( 'Jane Smith', 'custom-elementor-widgets' ),
                        'position' => __( 'Marketing Director', 'custom-elementor-widgets' ),
                        'company' => __( 'Another Company', 'custom-elementor-widgets' ),
                        'content' => __( 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.', 'custom-elementor-widgets' ),
                        'rating' => '4',
                    ],
                    [
                        'name' => __( 'Robert Johnson', 'custom-elementor-widgets' ),
                        'position' => __( 'CTO', 'custom-elementor-widgets' ),
                        'company' => __( 'Tech Solutions', 'custom-elementor-widgets' ),
                        'content' => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis.', 'custom-elementor-widgets' ),
                        'rating' => '5',
                    ],
                ],
                'title_field' => '{{{ name }}}',
            ]
        );

        $this->end_controls_section();

        // Display Settings Section
        $this->start_controls_section(
            'section_display_settings',
            [
                'label' => __( 'Display Settings', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'layout',
            [
                'label' => __( 'Layout', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'carousel',
                'options' => [
                    'carousel' => __( 'Carousel', 'custom-elementor-widgets' ),
                    'grid' => __( 'Grid', 'custom-elementor-widgets' ),
                    'masonry' => __( 'Masonry', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => __( 'Columns', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);',
                    '{{WRAPPER}} .custom-testimonials-masonry' => 'column-count: {{VALUE}};',
                ],
                'condition' => [
                    'layout!' => 'carousel',
                ],
            ]
        );

        $this->add_control(
            'show_image',
            [
                'label' => __( 'Show Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'image_position',
            [
                'label' => __( 'Image Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top' => __( 'Top', 'custom-elementor-widgets' ),
                    'left' => __( 'Left', 'custom-elementor-widgets' ),
                    'right' => __( 'Right', 'custom-elementor-widgets' ),
                ],
                'condition' => [
                    'show_image' => 'yes',
                ],
                'prefix_class' => 'custom-testimonial-image-position-',
            ]
        );

        $this->add_control(
            'show_rating',
            [
                'label' => __( 'Show Rating', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_quote_icon',
            [
                'label' => __( 'Show Quote Icon', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Carousel Settings Section
        $this->start_controls_section(
            'section_carousel_settings',
            [
                'label' => __( 'Carousel Settings', 'custom-elementor-widgets' ),
                'condition' => [
                    'layout' => 'carousel',
                ],
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Autoplay', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __( 'Autoplay Speed', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label' => __( 'Pause on Hover', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'infinite',
            [
                'label' => __( 'Infinite Loop', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'speed',
            [
                'label' => __( 'Animation Speed', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 500,
            ]
        );

        $this->add_control(
            'slides_to_show',
            [
                'label' => __( 'Slides to Show', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 10,
            ]
        );

        $this->add_control(
            'slides_to_scroll',
            [
                'label' => __( 'Slides to Scroll', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 10,
            ]
        );

        $this->add_control(
            'arrows',
            [
                'label' => __( 'Arrows', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'dots',
            [
                'label' => __( 'Dots', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Interactive Features Section
        $this->start_controls_section(
            'section_interactive_features',
            [
                'label' => __( 'Interactive Features', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'enable_animation',
            [
                'label' => __( 'Enable Animation', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'animation_type',
            [
                'label' => __( 'Animation Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'fade-in',
                'options' => [
                    'fade-in' => __( 'Fade In', 'custom-elementor-widgets' ),
                    'slide-up' => __( 'Slide Up', 'custom-elementor-widgets' ),
                    'slide-down' => __( 'Slide Down', 'custom-elementor-widgets' ),
                    'slide-left' => __( 'Slide Left', 'custom-elementor-widgets' ),
                    'slide-right' => __( 'Slide Right', 'custom-elementor-widgets' ),
                    'zoom-in' => __( 'Zoom In', 'custom-elementor-widgets' ),
                    'zoom-out' => __( 'Zoom Out', 'custom-elementor-widgets' ),
                    'flip' => __( 'Flip', 'custom-elementor-widgets' ),
                    'rotate' => __( 'Rotate', 'custom-elementor-widgets' ),
                    'bounce' => __( 'Bounce', 'custom-elementor-widgets' ),
                ],
                'condition' => [
                    'enable_animation' => 'yes',
                ],
                'prefix_class' => 'custom-testimonial-animation-',
            ]
        );

        $this->add_control(
            'hover_effect',
            [
                'label' => __( 'Hover Effect', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __( 'None', 'custom-elementor-widgets' ),
                    'grow' => __( 'Grow', 'custom-elementor-widgets' ),
                    'shrink' => __( 'Shrink', 'custom-elementor-widgets' ),
                    'shadow' => __( 'Shadow', 'custom-elementor-widgets' ),
                    'float' => __( 'Float', 'custom-elementor-widgets' ),
                    'wobble' => __( 'Wobble', 'custom-elementor-widgets' ),
                    'rotate' => __( 'Rotate', 'custom-elementor-widgets' ),
                    'blur' => __( 'Blur', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'custom-testimonial-hover-',
            ]
        );

        $this->add_control(
            'content_reveal',
            [
                'label' => __( 'Content Reveal', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __( 'None', 'custom-elementor-widgets' ),
                    'click' => __( 'On Click', 'custom-elementor-widgets' ),
                    'hover' => __( 'On Hover', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'custom-testimonial-reveal-',
            ]
        );

        $this->end_controls_section();

        // Item Style Section
        $this->start_controls_section(
            'section_item_style',
            [
                'label' => __( 'Testimonial Item', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'item_gap',
            [
                'label' => __( 'Item Gap', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 30,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-grid' => 'grid-gap: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .custom-testimonials-carousel .slick-slide' => 'padding: 0 calc({{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .custom-testimonials-carousel .slick-list' => 'margin: 0 calc(-{{SIZE}}{{UNIT}} / 2);',
                    '{{WRAPPER}} .custom-testimonials-masonry .custom-testimonial-item' => 'padding: calc({{SIZE}}{{UNIT}} / 2);',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-item-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'item_border',
                'selector' => '{{WRAPPER}} .custom-testimonial-item-inner',
            ]
        );

        $this->add_responsive_control(
            'item_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-item-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'item_style_tabs' );

        $this->start_controls_tab(
            'item_style_normal',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'item_background',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .custom-testimonial-item-inner',
                'exclude' => [ 'image' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_box_shadow',
                'selector' => '{{WRAPPER}} .custom-testimonial-item-inner',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'item_style_hover',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'item_background_hover',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .custom-testimonial-item-inner:hover',
                'exclude' => [ 'image' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_box_shadow_hover',
                'selector' => '{{WRAPPER}} .custom-testimonial-item-inner:hover',
            ]
        );

        $this->add_control(
            'item_border_color_hover',
            [
                'label' => __( 'Border Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-item-inner:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'item_border_border!' => '',
                ],
            ]
        );

        $this->add_control(
            'item_transition',
            [
                'label' => __( 'Transition Duration', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.3,
                ],
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-item-inner' => 'transition: all {{SIZE}}s ease',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        // Image Style Section
        $this->start_controls_section(
            'section_image_style',
            [
                'label' => __( 'Image', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 300,
                    ],
                    '%' => [
                        'min' => 5,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-image img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .custom-testimonial-image img',
            ]
        );

        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_box_shadow',
                'selector' => '{{WRAPPER}} .custom-testimonial-image img',
            ]
        );

        $this->add_responsive_control(
            'image_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-testimonial-image-position-top .custom-testimonial-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.custom-testimonial-image-position-left .custom-testimonial-image' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.custom-testimonial-image-position-right .custom-testimonial-image' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Content Style Section
        $this->start_controls_section(
            'section_content_style',
            [
                'label' => __( 'Content', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .custom-testimonial-content',
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Name Style Section
        $this->start_controls_section(
            'section_name_style',
            [
                'label' => __( 'Name', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .custom-testimonial-name',
            ]
        );

        $this->add_responsive_control(
            'name_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Position & Company Style Section
        $this->start_controls_section(
            'section_position_style',
            [
                'label' => __( 'Position & Company', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'position_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-position' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'position_typography',
                'selector' => '{{WRAPPER}} .custom-testimonial-position',
            ]
        );

        $this->end_controls_section();

        // Rating Style Section
        $this->start_controls_section(
            'section_rating_style',
            [
                'label' => __( 'Rating', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_rating' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'star_color',
            [
                'label' => __( 'Star Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#FFD10F',
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-rating i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'empty_star_color',
            [
                'label' => __( 'Empty Star Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#D8D8D8',
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-rating i.fa-star-o' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'star_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-rating i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'star_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-rating' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Quote Icon Style Section
        $this->start_controls_section(
            'section_quote_icon_style',
            [
                'label' => __( 'Quote Icon', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_quote_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'quote_icon_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.1)',
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-quote-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'quote_icon_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonial-quote-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'quote_icon_position',
            [
                'label' => __( 'Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'top-right',
                'options' => [
                    'top-left' => __( 'Top Left', 'custom-elementor-widgets' ),
                    'top-right' => __( 'Top Right', 'custom-elementor-widgets' ),
                    'bottom-left' => __( 'Bottom Left', 'custom-elementor-widgets' ),
                    'bottom-right' => __( 'Bottom Right', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'custom-quote-icon-position-',
            ]
        );

        $this->end_controls_section();

        // Navigation Style Section
        $this->start_controls_section(
            'section_navigation_style',
            [
                'label' => __( 'Navigation', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout' => 'carousel',
                ],
            ]
        );

        $this->add_control(
            'heading_arrows',
            [
                'label' => __( 'Arrows', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'arrows' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'arrows_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-prev, {{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-next' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'arrows' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'arrows_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-prev, {{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-next' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'arrows' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'arrows_background',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-prev, {{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-next' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'arrows' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'arrows_border',
                'selector' => '{{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-prev, {{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-next',
                'condition' => [
                    'arrows' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-prev, {{WRAPPER}} .custom-testimonials-carousel-nav .custom-nav-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'arrows' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'heading_dots',
            [
                'label' => __( 'Dots', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'dots' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'dots_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-carousel-dots .custom-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'dots' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-carousel-dots .custom-dot' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'dots' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'dots_active_color',
            [
                'label' => __( 'Active Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-testimonials-carousel-dots .custom-dot.active' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'dots' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render star rating.
     *
     * @param int $rating The rating.
     * @return string
     */
    private function render_stars( $rating ) {
        $stars = '';
        $full_stars = floor( $rating );
        $half_stars = ceil( $rating - $full_stars );
        $empty_stars = 5 - $full_stars - $half_stars;

        for ( $i = 0; $i < $full_stars; $i++ ) {
            $stars .= '<i class="fa fa-star" aria-hidden="true"></i>';
        }

        for ( $i = 0; $i < $half_stars; $i++ ) {
            $stars .= '<i class="fa fa-star-half-o" aria-hidden="true"></i>';
        }

        for ( $i = 0; $i < $empty_stars; $i++ ) {
            $stars .= '<i class="fa fa-star-o" aria-hidden="true"></i>';
        }

        return $stars;
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        if ( empty( $settings['testimonials'] ) ) {
            return;
        }

        // Determine the layout class
        $layout_class = 'custom-testimonials-' . $settings['layout'];
        
        // Carousel settings
        $carousel_data = '';
        if ( 'carousel' === $settings['layout'] ) {
            $carousel_settings = [
                'autoplay' => 'yes' === $settings['autoplay'] ? true : false,
                'autoplaySpeed' => intval( $settings['autoplay_speed'] ),
                'pauseOnHover' => 'yes' === $settings['pause_on_hover'] ? true : false,
                'infinite' => 'yes' === $settings['infinite'] ? true : false,
                'speed' => intval( $settings['speed'] ),
                'slidesToShow' => intval( $settings['slides_to_show'] ),
                'slidesToScroll' => intval( $settings['slides_to_scroll'] ),
                'arrows' => 'yes' === $settings['arrows'] ? true : false,
                'dots' => 'yes' === $settings['dots'] ? true : false,
            ];
            $carousel_data = ' data-carousel=\'' . json_encode( $carousel_settings ) . '\'';
        }

        // Content reveal settings
        $reveal_class = '';
        if ( 'click' === $settings['content_reveal'] ) {
            $reveal_class = ' custom-testimonial-content-hidden';
        }
        
        // Start output
        ?>
        <div class="custom-testimonials-container <?php echo esc_attr( $layout_class ); ?>"<?php echo $carousel_data; ?>>
            <?php if ( 'carousel' === $settings['layout'] && 'yes' === $settings['arrows'] ) : ?>
                <div class="custom-testimonials-carousel-nav">
                    <div class="custom-nav-prev">
                        <i class="fa fa-angle-left" aria-hidden="true"></i>
                    </div>
                    <div class="custom-nav-next">
                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                    </div>
                </div>
            <?php endif; ?>

            <div class="custom-testimonials-wrapper">
                <?php foreach ( $settings['testimonials'] as $index => $testimonial ) : 
                    $testimonial_key = $this->get_repeater_setting_key( 'testimonial', 'testimonials', $index );
                    $this->add_render_attribute( $testimonial_key, 'class', [
                        'custom-testimonial-item',
                        'elementor-repeater-item-' . $testimonial['_id'],
                    ] );

                    $link_url = ! empty( $testimonial['link']['url'] ) ? $testimonial['link']['url'] : '';
                    $link_target = ! empty( $testimonial['link']['is_external'] ) ? ' target="_blank"' : '';
                    $link_nofollow = ! empty( $testimonial['link']['nofollow'] ) ? ' rel="nofollow"' : '';
                    
                    $has_link = ! empty( $link_url );
                    
                    // Set animation delay
                    $animation_delay = '';
                    if ( 'yes' === $settings['enable_animation'] ) {
                        $animation_delay = ' style="animation-delay: ' . $index * 0.2 . 's;"';
                    }
                    ?>
                    <div <?php echo $this->get_render_attribute_string( $testimonial_key ); ?><?php echo $animation_delay; ?>>
                        <div class="custom-testimonial-item-inner">
                            <?php if ( 'yes' === $settings['show_quote_icon'] ) : ?>
                                <div class="custom-testimonial-quote-icon">
                                    <i class="fa fa-quote-right" aria-hidden="true"></i>
                                </div>
                            <?php endif; ?>

                            <?php if ( 'yes' === $settings['show_image'] && ! empty( $testimonial['image']['url'] ) && 'top' === $settings['image_position'] ) : ?>
                                <div class="custom-testimonial-image">
                                    <?php if ( $has_link ) : ?>
                                        <a href="<?php echo esc_url( $link_url ); ?>"<?php echo $link_target . $link_nofollow; ?>>
                                    <?php endif; ?>
                                        <img src="<?php echo esc_url( $testimonial['image']['url'] ); ?>" alt="<?php echo esc_attr( $testimonial['name'] ); ?>">
                                    <?php if ( $has_link ) : ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <div class="custom-testimonial-text-wrapper">
                                <?php if ( 'yes' === $settings['show_image'] && ! empty( $testimonial['image']['url'] ) && 'left' === $settings['image_position'] ) : ?>
                                    <div class="custom-testimonial-image">
                                        <?php if ( $has_link ) : ?>
                                            <a href="<?php echo esc_url( $link_url ); ?>"<?php echo $link_target . $link_nofollow; ?>>
                                        <?php endif; ?>
                                            <img src="<?php echo esc_url( $testimonial['image']['url'] ); ?>" alt="<?php echo esc_attr( $testimonial['name'] ); ?>">
                                        <?php if ( $has_link ) : ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                <div class="custom-testimonial-content-wrapper">
                                    <div class="custom-testimonial-content<?php echo esc_attr( $reveal_class ); ?>">
                                        <?php echo wp_kses_post( $testimonial['content'] ); ?>
                                    </div>

                                    <?php if ( 'click' === $settings['content_reveal'] ) : ?>
                                        <div class="custom-testimonial-read-more">
                                            <span class="custom-testimonial-read-more-text"><?php echo esc_html__( 'Read More', 'custom-elementor-widgets' ); ?></span>
                                        </div>
                                    <?php endif; ?>

                                    <div class="custom-testimonial-meta">
                                        <?php if ( ! empty( $testimonial['name'] ) ) : ?>
                                            <div class="custom-testimonial-name">
                                                <?php if ( $has_link ) : ?>
                                                    <a href="<?php echo esc_url( $link_url ); ?>"<?php echo $link_target . $link_nofollow; ?>>
                                                <?php endif; ?>
                                                    <?php echo esc_html( $testimonial['name'] ); ?>
                                                <?php if ( $has_link ) : ?>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ( ! empty( $testimonial['position'] ) || ! empty( $testimonial['company'] ) ) : ?>
                                            <div class="custom-testimonial-position">
                                                <?php 
                                                if ( ! empty( $testimonial['position'] ) ) {
                                                    echo esc_html( $testimonial['position'] );
                                                }
                                                
                                                if ( ! empty( $testimonial['position'] ) && ! empty( $testimonial['company'] ) ) {
                                                    echo esc_html( ', ' );
                                                }
                                                
                                                if ( ! empty( $testimonial['company'] ) ) {
                                                    echo esc_html( $testimonial['company'] );
                                                }
                                                ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ( 'yes' === $settings['show_rating'] && ! empty( $testimonial['rating'] ) ) : ?>
                                            <div class="custom-testimonial-rating">
                                                <?php echo $this->render_stars( $testimonial['rating'] ); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php if ( 'yes' === $settings['show_image'] && ! empty( $testimonial['image']['url'] ) && 'right' === $settings['image_position'] ) : ?>
                                    <div class="custom-testimonial-image">
                                        <?php if ( $has_link ) : ?>
                                            <a href="<?php echo esc_url( $link_url ); ?>"<?php echo $link_target . $link_nofollow; ?>>
                                        <?php endif; ?>
                                            <img src="<?php echo esc_url( $testimonial['image']['url'] ); ?>" alt="<?php echo esc_attr( $testimonial['name'] ); ?>">
                                        <?php if ( $has_link ) : ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if ( 'carousel' === $settings['layout'] && 'yes' === $settings['dots'] ) : ?>
                <div class="custom-testimonials-carousel-dots">
                    <?php for ( $i = 0; $i < count( $settings['testimonials'] ); $i++ ) : ?>
                        <span class="custom-dot<?php echo 0 === $i ? ' active' : ''; ?>"></span>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <#
        // Determine the layout class
        var layoutClass = 'custom-testimonials-' + settings.layout;
        
        // Carousel settings
        var carouselData = '';
        if ( 'carousel' === settings.layout ) {
            var carouselSettings = {
                autoplay: 'yes' === settings.autoplay ? true : false,
                autoplaySpeed: parseInt( settings.autoplay_speed ),
                pauseOnHover: 'yes' === settings.pause_on_hover ? true : false,
                infinite: 'yes' === settings.infinite ? true : false,
                speed: parseInt( settings.speed ),
                slidesToShow: parseInt( settings.slides_to_show ),
                slidesToScroll: parseInt( settings.slides_to_scroll ),
                arrows: 'yes' === settings.arrows ? true : false,
                dots: 'yes' === settings.dots ? true : false
            };
            carouselData = ' data-carousel=\'' + JSON.stringify( carouselSettings ) + '\'';
        }
        
        // Function to render stars
        function renderStars( rating ) {
            var stars = '';
            var fullStars = Math.floor( rating );
            var halfStars = Math.ceil( rating - fullStars );
            var emptyStars = 5 - fullStars - halfStars;
            
            for ( var i = 0; i < fullStars; i++ ) {
                stars += '<i class="fa fa-star" aria-hidden="true"></i>';
            }
            
            for ( var i = 0; i < halfStars; i++ ) {
                stars += '<i class="fa fa-star-half-o" aria-hidden="true"></i>';
            }
            
            for ( var i = 0; i < emptyStars; i++ ) {
                stars += '<i class="fa fa-star-o" aria-hidden="true"></i>';
            }
            
            return stars;
        }
        
        // Content reveal settings
        var revealClass = '';
        if ( 'click' === settings.content_reveal ) {
            revealClass = ' custom-testimonial-content-hidden';
        }
        #>
        <div class="custom-testimonials-container {{{ layoutClass }}}" {{{ carouselData }}}>
            <# if ( 'carousel' === settings.layout && 'yes' === settings.arrows ) { #>
                <div class="custom-testimonials-carousel-nav">
                    <div class="custom-nav-prev">
                        <i class="fa fa-angle-left" aria-hidden="true"></i>
                    </div>
                    <div class="custom-nav-next">
                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                    </div>
                </div>
            <# } #>

            <div class="custom-testimonials-wrapper">
                <# _.each( settings.testimonials, function( testimonial, index ) { 
                    var animationDelay = '';
                    if ( 'yes' === settings.enable_animation ) {
                        animationDelay = ' style="animation-delay: ' + index * 0.2 + 's;"';
                    }
                    
                    var linkUrl = testimonial.link.url ? testimonial.link.url : '';
                    var linkTarget = testimonial.link.is_external ? ' target="_blank"' : '';
                    var linkNofollow = testimonial.link.nofollow ? ' rel="nofollow"' : '';
                    
                    var hasLink = linkUrl ? true : false;
                #>
                    <div class="custom-testimonial-item elementor-repeater-item-{{ testimonial._id }}" {{{ animationDelay }}}>
                        <div class="custom-testimonial-item-inner">
                            <# if ( 'yes' === settings.show_quote_icon ) { #>
                                <div class="custom-testimonial-quote-icon">
                                    <i class="fa fa-quote-right" aria-hidden="true"></i>
                                </div>
                            <# } #>

                            <# if ( 'yes' === settings.show_image && testimonial.image.url && 'top' === settings.image_position ) { #>
                                <div class="custom-testimonial-image">
                                    <# if ( hasLink ) { #>
                                        <a href="{{ linkUrl }}"{{{ linkTarget }}}{{{ linkNofollow }}}>
                                    <# } #>
                                        <img src="{{ testimonial.image.url }}" alt="{{ testimonial.name }}">
                                    <# if ( hasLink ) { #>
                                        </a>
                                    <# } #>
                                </div>
                            <# } #>

                            <div class="custom-testimonial-text-wrapper">
                                <# if ( 'yes' === settings.show_image && testimonial.image.url && 'left' === settings.image_position ) { #>
                                    <div class="custom-testimonial-image">
                                        <# if ( hasLink ) { #>
                                            <a href="{{ linkUrl }}"{{{ linkTarget }}}{{{ linkNofollow }}}>
                                        <# } #>
                                            <img src="{{ testimonial.image.url }}" alt="{{ testimonial.name }}">
                                        <# if ( hasLink ) { #>
                                            </a>
                                        <# } #>
                                    </div>
                                <# } #>

                                <div class="custom-testimonial-content-wrapper">
                                    <div class="custom-testimonial-content{{{ revealClass }}}">
                                        {{{ testimonial.content }}}
                                    </div>

                                    <# if ( 'click' === settings.content_reveal ) { #>
                                        <div class="custom-testimonial-read-more">
                                            <span class="custom-testimonial-read-more-text"><?php echo esc_html__( 'Read More', 'custom-elementor-widgets' ); ?></span>
                                        </div>
                                    <# } #>

                                    <div class="custom-testimonial-meta">
                                        <# if ( testimonial.name ) { #>
                                            <div class="custom-testimonial-name">
                                                <# if ( hasLink ) { #>
                                                    <a href="{{ linkUrl }}"{{{ linkTarget }}}{{{ linkNofollow }}}>
                                                <# } #>
                                                    {{ testimonial.name }}
                                                <# if ( hasLink ) { #>
                                                    </a>
                                                <# } #>
                                            </div>
                                        <# } #>

                                        <# if ( testimonial.position || testimonial.company ) { #>
                                            <div class="custom-testimonial-position">
                                                <# 
                                                if ( testimonial.position ) {
                                                    #>{{ testimonial.position }}<#
                                                }
                                                
                                                if ( testimonial.position && testimonial.company ) {
                                                    #>, <#
                                                }
                                                
                                                if ( testimonial.company ) {
                                                    #>{{ testimonial.company }}<#
                                                }
                                                #>
                                            </div>
                                        <# } #>

                                        <# if ( 'yes' === settings.show_rating && testimonial.rating ) { #>
                                            <div class="custom-testimonial-rating">
                                                {{{ renderStars( testimonial.rating ) }}}
                                            </div>
                                        <# } #>
                                    </div>
                                </div>

                                <# if ( 'yes' === settings.show_image && testimonial.image.url && 'right' === settings.image_position ) { #>
                                    <div class="custom-testimonial-image">
                                        <# if ( hasLink ) { #>
                                            <a href="{{ linkUrl }}"{{{ linkTarget }}}{{{ linkNofollow }}}>
                                        <# } #>
                                            <img src="{{ testimonial.image.url }}" alt="{{ testimonial.name }}">
                                        <# if ( hasLink ) { #>
                                            </a>
                                        <# } #>
                                    </div>
                                <# } #>
                            </div>
                        </div>
                    </div>
                <# } ); #>
            </div>

            <# if ( 'carousel' === settings.layout && 'yes' === settings.dots ) { #>
                <div class="custom-testimonials-carousel-dots">
                    <# for ( var i = 0; i < settings.testimonials.length; i++ ) { #>
                        <span class="custom-dot<# if ( 0 === i ) { #> active<# } #>"></span>
                    <# } #>
                </div>
            <# } #>
        </div>
        <?php
    }
}
