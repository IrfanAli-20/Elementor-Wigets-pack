<?php
/**
 * Advanced Post Grid Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Advanced Post Grid Widget Class
 */
class Advanced_Post_Grid_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_advanced_post_grid';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Advanced Post Grid', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-posts-grid';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'post', 'grid', 'blog', 'advanced', 'masonry' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Query Settings
        $this->start_controls_section(
            'section_query',
            [
                'label' => __( 'Query', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_type',
            [
                'label' => __( 'Post Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'post',
                'options' => $this->get_post_types(),
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __( 'Posts Per Page', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 6,
                'min' => 1,
                'max' => 100,
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => __( 'Order By', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => __( 'Date', 'custom-elementor-widgets' ),
                    'title' => __( 'Title', 'custom-elementor-widgets' ),
                    'menu_order' => __( 'Menu Order', 'custom-elementor-widgets' ),
                    'rand' => __( 'Random', 'custom-elementor-widgets' ),
                    'comment_count' => __( 'Comment Count', 'custom-elementor-widgets' ),
                    'modified' => __( 'Last Modified', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __( 'Order', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'desc',
                'options' => [
                    'asc' => __( 'Ascending', 'custom-elementor-widgets' ),
                    'desc' => __( 'Descending', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'include_categories',
            [
                'label' => __( 'Include Categories', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'options' => $this->get_post_categories(),
                'multiple' => true,
                'label_block' => true,
                'condition' => [
                    'post_type' => 'post',
                ],
            ]
        );

        $this->add_control(
            'exclude_posts',
            [
                'label' => __( 'Exclude Posts', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'description' => __( 'Enter post IDs separated by commas to exclude specific posts', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'offset',
            [
                'label' => __( 'Offset', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 0,
                'min' => 0,
                'max' => 100,
                'description' => __( 'Number of posts to skip', 'custom-elementor-widgets' ),
            ]
        );

        $this->end_controls_section();

        // Layout Settings
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Layout', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __( 'Layout Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'grid',
                'options' => [
                    'grid' => __( 'Grid', 'custom-elementor-widgets' ),
                    'masonry' => __( 'Masonry', 'custom-elementor-widgets' ),
                    'list' => __( 'List', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => __( 'Columns', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                ],
                'prefix_class' => 'elementor-grid-',
                'frontend_available' => true,
                'condition' => [
                    'layout_type!' => 'list',
                ],
            ]
        );

        $this->add_control(
            'equal_height',
            [
                'label' => __( 'Equal Height', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'layout_type' => 'grid',
                ],
                'prefix_class' => 'custom-posts-equal-height-',
            ]
        );

        $this->add_control(
            'post_elements_heading',
            [
                'label' => __( 'Post Elements', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'show_image',
            [
                'label' => __( 'Featured Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'exclude' => [ 'custom' ],
                'default' => 'medium',
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_title',
            [
                'label' => __( 'Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => __( 'Title HTML Tag', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h3',
                'condition' => [
                    'show_title' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_meta',
            [
                'label' => __( 'Meta', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'meta_position',
            [
                'label' => __( 'Meta Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'below_title',
                'options' => [
                    'above_title' => __( 'Above Title', 'custom-elementor-widgets' ),
                    'below_title' => __( 'Below Title', 'custom-elementor-widgets' ),
                    'below_excerpt' => __( 'Below Excerpt', 'custom-elementor-widgets' ),
                ],
                'condition' => [
                    'show_meta' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'meta_data',
            [
                'label' => __( 'Meta Data', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => [
                    'author' => __( 'Author', 'custom-elementor-widgets' ),
                    'date' => __( 'Date', 'custom-elementor-widgets' ),
                    'categories' => __( 'Categories', 'custom-elementor-widgets' ),
                    'comments' => __( 'Comments', 'custom-elementor-widgets' ),
                ],
                'default' => [ 'author', 'date' ],
                'condition' => [
                    'show_meta' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => __( 'Excerpt', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label' => __( 'Excerpt Length', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 25,
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_read_more',
            [
                'label' => __( 'Read More', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => __( 'Read More Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Read More »', 'custom-elementor-widgets' ),
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Pagination Settings
        $this->start_controls_section(
            'section_pagination',
            [
                'label' => __( 'Pagination', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'pagination_type',
            [
                'label' => __( 'Pagination', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __( 'None', 'custom-elementor-widgets' ),
                    'numbers' => __( 'Numbers', 'custom-elementor-widgets' ),
                    'load_more' => __( 'Load More Button', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'load_more_text',
            [
                'label' => __( 'Load More Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Load More', 'custom-elementor-widgets' ),
                'condition' => [
                    'pagination_type' => 'load_more',
                ],
            ]
        );

        $this->end_controls_section();

        // Filter Settings
        $this->start_controls_section(
            'section_filters',
            [
                'label' => __( 'Filters', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_filters',
            [
                'label' => __( 'Show Filters', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'post_type' => 'post',
                ],
            ]
        );

        $this->add_control(
            'filter_by',
            [
                'label' => __( 'Filter By', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'category',
                'options' => [
                    'category' => __( 'Categories', 'custom-elementor-widgets' ),
                    'tag' => __( 'Tags', 'custom-elementor-widgets' ),
                ],
                'condition' => [
                    'show_filters' => 'yes',
                    'post_type' => 'post',
                ],
            ]
        );

        $this->add_control(
            'all_filter_label',
            [
                'label' => __( 'All Filter Label', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'All', 'custom-elementor-widgets' ),
                'condition' => [
                    'show_filters' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'filter_alignment',
            [
                'label' => __( 'Filter Alignment', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filters' => 'text-align: {{VALUE}};',
                ],
                'condition' => [
                    'show_filters' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Image Style Section
        $this->start_controls_section(
            'section_image_style',
            [
                'label' => __( 'Image', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_box_shadow',
                'selector' => '{{WRAPPER}} .custom-post-grid-image img',
            ]
        );

        $this->add_responsive_control(
            'image_space',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'image_hover_effect',
            [
                'label' => __( 'Hover Effect', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __( 'None', 'custom-elementor-widgets' ),
                    'zoom' => __( 'Zoom', 'custom-elementor-widgets' ),
                    'opacity' => __( 'Opacity', 'custom-elementor-widgets' ),
                    'rotate' => __( 'Rotate', 'custom-elementor-widgets' ),
                    'grayscale' => __( 'Grayscale', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'custom-post-grid-image-effect-',
            ]
        );

        $this->end_controls_section();

        // Title Style Section
        $this->start_controls_section(
            'section_title_style',
            [
                'label' => __( 'Title', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_title' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => __( 'Hover Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-title a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .custom-post-grid-title',
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Meta Style Section
        $this->start_controls_section(
            'section_meta_style',
            [
                'label' => __( 'Meta', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_meta' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'meta_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-meta' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_link_color',
            [
                'label' => __( 'Link Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-meta a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_link_hover_color',
            [
                'label' => __( 'Link Hover Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-meta a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'meta_typography',
                'selector' => '{{WRAPPER}} .custom-post-grid-meta',
            ]
        );

        $this->add_responsive_control(
            'meta_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-meta' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'meta_separator',
            [
                'label' => __( 'Separator', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '/',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-meta-separator' => 'content: "{{VALUE}}";',
                ],
            ]
        );

        $this->end_controls_section();

        // Excerpt Style Section
        $this->start_controls_section(
            'section_excerpt_style',
            [
                'label' => __( 'Excerpt', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'excerpt_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-excerpt' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typography',
                'selector' => '{{WRAPPER}} .custom-post-grid-excerpt',
            ]
        );

        $this->add_responsive_control(
            'excerpt_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-excerpt' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Read More Style Section
        $this->start_controls_section(
            'section_read_more_style',
            [
                'label' => __( 'Read More', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'read_more_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-read-more' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'read_more_hover_color',
            [
                'label' => __( 'Hover Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-read-more:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'read_more_typography',
                'selector' => '{{WRAPPER}} .custom-post-grid-read-more',
            ]
        );

        $this->add_control(
            'read_more_style',
            [
                'label' => __( 'Style', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'text',
                'options' => [
                    'text' => __( 'Text', 'custom-elementor-widgets' ),
                    'button' => __( 'Button', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'custom-post-grid-read-more-style-',
            ]
        );

        $this->add_control(
            'read_more_text_decoration',
            [
                'label' => __( 'Text Decoration', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __( 'None', 'custom-elementor-widgets' ),
                    'underline' => __( 'Underline', 'custom-elementor-widgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-read-more' => 'text-decoration: {{VALUE}};',
                ],
                'condition' => [
                    'read_more_style' => 'text',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-read-more' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'read_more_style' => 'button',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_hover_background_color',
            [
                'label' => __( 'Hover Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-read-more:hover' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'read_more_style' => 'button',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-read-more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'read_more_style' => 'button',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'read_more_style' => 'button',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'read_more_button_border',
                'selector' => '{{WRAPPER}} .custom-post-grid-read-more',
                'condition' => [
                    'read_more_style' => 'button',
                ],
            ]
        );

        $this->end_controls_section();

        // Filters Style Section
        $this->start_controls_section(
            'section_filters_style',
            [
                'label' => __( 'Filters', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_filters' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'filters_typography',
                'selector' => '{{WRAPPER}} .custom-post-grid-filter',
            ]
        );

        $this->add_responsive_control(
            'filters_spacing',
            [
                'label' => __( 'Space Between', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'filters_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filters' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'filter_tabs_style' );

        $this->start_controls_tab(
            'filter_normal_style',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'filter_normal_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'filter_normal_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'filter_hover_style',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'filter_hover_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'filter_hover_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'filter_active_style',
            [
                'label' => __( 'Active', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'filter_active_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter.active' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'filter_active_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter.active' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'filter_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'filter_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Pagination Style Section
        $this->start_controls_section(
            'section_pagination_style',
            [
                'label' => __( 'Pagination', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'pagination_type!' => 'none',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'pagination_typography',
                'selector' => '{{WRAPPER}} .custom-post-grid-pagination .page-numbers, {{WRAPPER}} .custom-post-grid-load-more',
            ]
        );

        $this->add_responsive_control(
            'pagination_spacing',
            [
                'label' => __( 'Space Between', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pagination_type' => 'numbers',
                ],
            ]
        );

        $this->add_responsive_control(
            'pagination_top_spacing',
            [
                'label' => __( 'Top Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination, {{WRAPPER}} .custom-post-grid-load-more-wrapper' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'pagination_alignment',
            [
                'label' => __( 'Alignment', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination, {{WRAPPER}} .custom-post-grid-load-more-wrapper' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'pagination_tabs_style' );

        $this->start_controls_tab(
            'pagination_normal_style',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'pagination_normal_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers, {{WRAPPER}} .custom-post-grid-load-more' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pagination_normal_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers, {{WRAPPER}} .custom-post-grid-load-more' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'pagination_hover_style',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'pagination_hover_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers:hover, {{WRAPPER}} .custom-post-grid-load-more:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pagination_hover_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers:hover, {{WRAPPER}} .custom-post-grid-load-more:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'pagination_active_style',
            [
                'label' => __( 'Active', 'custom-elementor-widgets' ),
                'condition' => [
                    'pagination_type' => 'numbers',
                ],
            ]
        );

        $this->add_control(
            'pagination_active_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers.current' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pagination_active_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers.current' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'pagination_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers, {{WRAPPER}} .custom-post-grid-load-more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'pagination_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-post-grid-pagination .page-numbers, {{WRAPPER}} .custom-post-grid-load-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'pagination_border',
                'selector' => '{{WRAPPER}} .custom-post-grid-pagination .page-numbers, {{WRAPPER}} .custom-post-grid-load-more',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Get all registered post types
     *
     * @return array
     */
    private function get_post_types() {
        $post_types = get_post_types( [ 'public' => true ], 'objects' );
        $options = [];

        foreach ( $post_types as $post_type ) {
            $options[ $post_type->name ] = $post_type->label;
        }

        // Exclude unnecessary post types
        unset( $options['attachment'] );
        unset( $options['elementor_library'] );

        return $options;
    }

    /**
     * Get post categories
     *
     * @return array
     */
    private function get_post_categories() {
        $categories = get_categories( [
            'orderby' => 'name',
            'order'   => 'ASC',
            'hide_empty' => false,
        ] );

        $options = [];

        foreach ( $categories as $category ) {
            $options[ $category->term_id ] = $category->name;
        }

        return $options;
    }

    /**
     * Get custom excerpt
     *
     * @param int $length Excerpt length.
     * @return string
     */
    private function get_custom_excerpt( $length ) {
        $excerpt = get_the_excerpt();
        $excerpt = strip_shortcodes( $excerpt );
        $excerpt = strip_tags( $excerpt );
        $excerpt = substr( $excerpt, 0, $length );
        $excerpt = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
        $excerpt .= '...';
        
        return $excerpt;
    }

    /**
     * Render post meta
     *
     * @param array $settings Widget settings.
     */
    private function render_meta( $settings ) {
        if ( 'yes' !== $settings['show_meta'] ) {
            return;
        }

        $meta_data = $settings['meta_data'];
        ?>
        <div class="custom-post-grid-meta">
            <?php
            if ( in_array( 'author', $meta_data ) ) {
                echo '<span class="custom-post-grid-meta-item custom-post-grid-meta-author">';
                echo esc_html__( 'By ', 'custom-elementor-widgets' );
                echo '<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>';
                echo '</span>';
                
                if ( count( $meta_data ) > 1 && array_search( 'author', $meta_data ) < count( $meta_data ) - 1 ) {
                    echo '<span class="custom-post-grid-meta-separator"></span>';
                }
            }
            
            if ( in_array( 'date', $meta_data ) ) {
                echo '<span class="custom-post-grid-meta-item custom-post-grid-meta-date">';
                echo '<a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_date() ) . '</a>';
                echo '</span>';
                
                if ( count( $meta_data ) > 2 && array_search( 'date', $meta_data ) < count( $meta_data ) - 1 ) {
                    echo '<span class="custom-post-grid-meta-separator"></span>';
                }
            }
            
            if ( in_array( 'categories', $meta_data ) ) {
                $categories = get_the_category();
                if ( ! empty( $categories ) ) {
                    echo '<span class="custom-post-grid-meta-item custom-post-grid-meta-categories">';
                    $i = 0;
                    foreach ( $categories as $category ) {
                        if ( $i > 0 ) {
                            echo ', ';
                        }
                        echo '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a>';
                        $i++;
                    }
                    echo '</span>';
                    
                    if ( in_array( 'comments', $meta_data ) ) {
                        echo '<span class="custom-post-grid-meta-separator"></span>';
                    }
                }
            }
            
            if ( in_array( 'comments', $meta_data ) ) {
                echo '<span class="custom-post-grid-meta-item custom-post-grid-meta-comments">';
                echo '<a href="' . esc_url( get_comments_link() ) . '">';
                if ( get_comments_number() == 0 ) {
                    echo esc_html__( 'No Comments', 'custom-elementor-widgets' );
                } elseif ( get_comments_number() == 1 ) {
                    echo esc_html__( '1 Comment', 'custom-elementor-widgets' );
                } else {
                    echo esc_html( get_comments_number() ) . ' ' . esc_html__( 'Comments', 'custom-elementor-widgets' );
                }
                echo '</a>';
                echo '</span>';
            }
            ?>
        </div>
        <?php
    }

    /**
     * Render filters
     *
     * @param array $settings Widget settings.
     */
    private function render_filters( $settings ) {
        if ( 'yes' !== $settings['show_filters'] ) {
            return;
        }

        $filter_by = $settings['filter_by'];
        $all_label = $settings['all_filter_label'];
        
        if ( 'category' === $filter_by ) {
            $terms = get_categories( [
                'orderby' => 'name',
                'order'   => 'ASC',
                'hide_empty' => true,
            ] );
        } else {
            $terms = get_tags( [
                'orderby' => 'name',
                'order'   => 'ASC',
                'hide_empty' => true,
            ] );
        }

        if ( empty( $terms ) || is_wp_error( $terms ) ) {
            return;
        }
        ?>
        <div class="custom-post-grid-filters">
            <span class="custom-post-grid-filter active" data-filter="*"><?php echo esc_html( $all_label ); ?></span>
            
            <?php foreach ( $terms as $term ) : ?>
                <span class="custom-post-grid-filter" data-filter=".<?php echo esc_attr( $filter_by . '-' . $term->slug ); ?>">
                    <?php echo esc_html( $term->name ); ?>
                </span>
            <?php endforeach; ?>
        </div>
        <?php
    }

    /**
     * Render pagination
     *
     * @param array $settings Widget settings.
     * @param int $query_total Total number of pages.
     */
    private function render_pagination( $settings, $query_total ) {
        if ( 'none' === $settings['pagination_type'] ) {
            return;
        }

        $current_page = max( 1, get_query_var( 'paged' ) );

        if ( 'numbers' === $settings['pagination_type'] ) {
            if ( $query_total > 1 ) {
                echo '<div class="custom-post-grid-pagination">';
                $pagination_args = [
                    'base'    => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                    'format'  => '?paged=%#%',
                    'current' => $current_page,
                    'total'   => $query_total,
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'type' => 'list',
                ];
                
                echo paginate_links( $pagination_args );
                echo '</div>';
            }
        } elseif ( 'load_more' === $settings['pagination_type'] && $current_page < $query_total ) {
            echo '<div class="custom-post-grid-load-more-wrapper">';
            echo '<button class="custom-post-grid-load-more" data-page="' . esc_attr( $current_page ) . '" data-max="' . esc_attr( $query_total ) . '">';
            echo esc_html( $settings['load_more_text'] );
            echo '</button>';
            echo '</div>';
        }
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $this->add_render_attribute( 'wrapper', 'class', 'custom-post-grid-wrapper' );
        $this->add_render_attribute( 'container', 'class', 'custom-post-grid-container' );
        
        // Build query
        $args = [
            'post_type'      => $settings['post_type'],
            'posts_per_page' => $settings['posts_per_page'],
            'order'          => $settings['order'],
            'orderby'        => $settings['orderby'],
            'offset'         => $settings['offset'],
            'post_status'    => 'publish',
        ];

        // Handle pagination
        if ( 'numbers' === $settings['pagination_type'] ) {
            $args['paged'] = max( 1, get_query_var( 'paged' ) );
        }

        // Include categories
        if ( $settings['include_categories'] && $settings['post_type'] === 'post' ) {
            $args['category__in'] = $settings['include_categories'];
        }

        // Exclude posts
        if ( $settings['exclude_posts'] ) {
            $exclude_ids = explode( ',', $settings['exclude_posts'] );
            $args['post__not_in'] = array_map( 'intval', $exclude_ids );
        }

        $query = new \WP_Query( $args );
        
        if ( $query->have_posts() ) :
            // Render filters
            $this->render_filters( $settings );
            ?>
            
            <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
                <div <?php echo $this->get_render_attribute_string( 'container' ); ?> data-layout="<?php echo esc_attr( $settings['layout_type'] ); ?>">
                    <?php
                    while ( $query->have_posts() ) : $query->the_post();
                        // Get post terms for filtering
                        $filter_terms = '';
                        if ( 'yes' === $settings['show_filters'] ) {
                            if ( 'category' === $settings['filter_by'] ) {
                                $terms = get_the_category();
                                if ( ! empty( $terms ) ) {
                                    foreach ( $terms as $term ) {
                                        $filter_terms .= ' category-' . $term->slug;
                                    }
                                }
                            } else {
                                $terms = get_the_tags();
                                if ( ! empty( $terms ) ) {
                                    foreach ( $terms as $term ) {
                                        $filter_terms .= ' tag-' . $term->slug;
                                    }
                                }
                            }
                        }
                        
                        // Output post item
                        ?>
                        <div class="custom-post-grid-item<?php echo esc_attr( $filter_terms ); ?>">
                            <div class="custom-post-grid-item-inner">
                                <?php if ( 'yes' === $settings['show_image'] && has_post_thumbnail() ) : ?>
                                    <div class="custom-post-grid-image">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail( $settings['thumbnail_size'] ); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="custom-post-grid-content">
                                    <?php
                                    // Display meta above title
                                    if ( 'yes' === $settings['show_meta'] && 'above_title' === $settings['meta_position'] ) {
                                        $this->render_meta( $settings );
                                    }
                                    
                                    // Display title
                                    if ( 'yes' === $settings['show_title'] ) :
                                        $tag = $settings['title_tag'];
                                        ?>
                                        <<?php echo esc_html( $tag ); ?> class="custom-post-grid-title">
                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </<?php echo esc_html( $tag ); ?>>
                                    <?php endif; ?>
                                    
                                    <?php
                                    // Display meta below title
                                    if ( 'yes' === $settings['show_meta'] && 'below_title' === $settings['meta_position'] ) {
                                        $this->render_meta( $settings );
                                    }
                                    
                                    // Display excerpt
                                    if ( 'yes' === $settings['show_excerpt'] ) : ?>
                                        <div class="custom-post-grid-excerpt">
                                            <?php echo $this->get_custom_excerpt( $settings['excerpt_length'] ); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <?php
                                    // Display meta below excerpt
                                    if ( 'yes' === $settings['show_meta'] && 'below_excerpt' === $settings['meta_position'] ) {
                                        $this->render_meta( $settings );
                                    }
                                    
                                    // Display read more
                                    if ( 'yes' === $settings['show_read_more'] ) : ?>
                                        <div class="custom-post-grid-read-more-wrapper">
                                            <a href="<?php the_permalink(); ?>" class="custom-post-grid-read-more">
                                                <?php echo esc_html( $settings['read_more_text'] ); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
                
                <?php
                // Render pagination
                $this->render_pagination( $settings, $query->max_num_pages );
                ?>
            </div>
            <?php
            wp_reset_postdata();
        else :
            echo '<p>' . esc_html__( 'No posts found.', 'custom-elementor-widgets' ) . '</p>';
        endif;
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <#
        view.addRenderAttribute( 'wrapper', 'class', 'custom-post-grid-wrapper' );
        view.addRenderAttribute( 'container', 'class', 'custom-post-grid-container' );
        
        // Show Filters
        if ( 'yes' === settings.show_filters ) {
            #>
            <div class="custom-post-grid-filters">
                <span class="custom-post-grid-filter active" data-filter="*">{{ settings.all_filter_label }}</span>
                <span class="custom-post-grid-filter" data-filter=".sample-category">Category 1</span>
                <span class="custom-post-grid-filter" data-filter=".sample-category-2">Category 2</span>
            </div>
            <#
        }
        #>
        
        <div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
            <div {{{ view.getRenderAttributeString( 'container' ) }}} data-layout="{{ settings.layout_type }}">
                <# for ( var i = 0; i < 3; i++ ) { #>
                    <div class="custom-post-grid-item">
                        <div class="custom-post-grid-item-inner">
                            <# if ( 'yes' === settings.show_image ) { #>
                                <div class="custom-post-grid-image">
                                    <a href="#">
                                        <img src="<?php echo CUSTOM_ELEMENTOR_WIDGETS_URL . 'assets/img/placeholder.svg'; ?>" alt="Placeholder">
                                    </a>
                                </div>
                            <# } #>
                            
                            <div class="custom-post-grid-content">
                                <# if ( 'yes' === settings.show_meta && 'above_title' === settings.meta_position ) { #>
                                    <div class="custom-post-grid-meta">
                                        <# if ( -1 !== settings.meta_data.indexOf('author') ) { #>
                                            <span class="custom-post-grid-meta-item custom-post-grid-meta-author">
                                                By <a href="#">John Doe</a>
                                            </span>
                                            <span class="custom-post-grid-meta-separator"></span>
                                        <# } #>
                                        
                                        <# if ( -1 !== settings.meta_data.indexOf('date') ) { #>
                                            <span class="custom-post-grid-meta-item custom-post-grid-meta-date">
                                                <a href="#">April 1, 2023</a>
                                            </span>
                                        <# } #>
                                    </div>
                                <# } #>
                                
                                <# if ( 'yes' === settings.show_title ) { 
                                    var title = 'Sample Post Title';
                                    var titleTag = settings.title_tag;
                                #>
                                    <{{{ titleTag }}} class="custom-post-grid-title">
                                        <a href="#">{{{ title }}}</a>
                                    </{{{ titleTag }}}>
                                <# } #>
                                
                                <# if ( 'yes' === settings.show_meta && 'below_title' === settings.meta_position ) { #>
                                    <div class="custom-post-grid-meta">
                                        <# if ( -1 !== settings.meta_data.indexOf('author') ) { #>
                                            <span class="custom-post-grid-meta-item custom-post-grid-meta-author">
                                                By <a href="#">John Doe</a>
                                            </span>
                                            <span class="custom-post-grid-meta-separator"></span>
                                        <# } #>
                                        
                                        <# if ( -1 !== settings.meta_data.indexOf('date') ) { #>
                                            <span class="custom-post-grid-meta-item custom-post-grid-meta-date">
                                                <a href="#">April 1, 2023</a>
                                            </span>
                                        <# } #>
                                    </div>
                                <# } #>
                                
                                <# if ( 'yes' === settings.show_excerpt ) { #>
                                    <div class="custom-post-grid-excerpt">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                                    </div>
                                <# } #>
                                
                                <# if ( 'yes' === settings.show_meta && 'below_excerpt' === settings.meta_position ) { #>
                                    <div class="custom-post-grid-meta">
                                        <# if ( -1 !== settings.meta_data.indexOf('author') ) { #>
                                            <span class="custom-post-grid-meta-item custom-post-grid-meta-author">
                                                By <a href="#">John Doe</a>
                                            </span>
                                            <span class="custom-post-grid-meta-separator"></span>
                                        <# } #>
                                        
                                        <# if ( -1 !== settings.meta_data.indexOf('date') ) { #>
                                            <span class="custom-post-grid-meta-item custom-post-grid-meta-date">
                                                <a href="#">April 1, 2023</a>
                                            </span>
                                        <# } #>
                                    </div>
                                <# } #>
                                
                                <# if ( 'yes' === settings.show_read_more ) { #>
                                    <div class="custom-post-grid-read-more-wrapper">
                                        <a href="#" class="custom-post-grid-read-more">
                                            {{{ settings.read_more_text }}}
                                        </a>
                                    </div>
                                <# } #>
                            </div>
                        </div>
                    </div>
                <# } #>
            </div>
            
            <# if ( 'numbers' === settings.pagination_type ) { #>
                <div class="custom-post-grid-pagination">
                    <span class="page-numbers current">1</span>
                    <a class="page-numbers" href="#">2</a>
                    <a class="page-numbers" href="#">3</a>
                    <a class="next page-numbers" href="#">»</a>
                </div>
            <# } else if ( 'load_more' === settings.pagination_type ) { #>
                <div class="custom-post-grid-load-more-wrapper">
                    <button class="custom-post-grid-load-more">
                        {{{ settings.load_more_text }}}
                    </button>
                </div>
            <# } #>
        </div>
        <?php
    }
}
