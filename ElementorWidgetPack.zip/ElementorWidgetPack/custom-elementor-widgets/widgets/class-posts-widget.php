<?php
/**
 * Posts Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Posts Widget Class
 */
class Posts_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_posts';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Custom Posts', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-list';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Content', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_type',
            [
                'label' => __( 'Post Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'post',
                'options' => $this->get_post_types(),
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __( 'Posts Per Page', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 100,
                'step' => 1,
            ]
        );

        $this->add_control(
            'show_thumbnail',
            [
                'label' => __( 'Show Featured Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_title',
            [
                'label' => __( 'Show Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => __( 'Show Excerpt', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label' => __( 'Excerpt Length', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 20,
                'min' => 5,
                'max' => 200,
                'step' => 1,
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_read_more',
            [
                'label' => __( 'Show Read More', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => __( 'Read More Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Read More', 'custom-elementor-widgets' ),
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'column_gap',
            [
                'label' => __( 'Columns Gap', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 30,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-posts-grid' => 'grid-column-gap: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'row_gap',
            [
                'label' => __( 'Rows Gap', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 35,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-posts-grid' => 'grid-row-gap: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __( 'Title Typography', 'custom-elementor-widgets' ),
                'selector' => '{{WRAPPER}} .custom-post-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typography',
                'label' => __( 'Excerpt Typography', 'custom-elementor-widgets' ),
                'selector' => '{{WRAPPER}} .custom-post-excerpt',
            ]
        );

        $this->add_control(
            'excerpt_color',
            [
                'label' => __( 'Excerpt Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#777',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-excerpt' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'read_more_color',
            [
                'label' => __( 'Read More Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#61ce70',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-read-more' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'read_more_hover_color',
            [
                'label' => __( 'Read More Hover Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#4bbb5a',
                'selectors' => [
                    '{{WRAPPER}} .custom-post-read-more:hover' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Layout Section
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Layout', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => __( 'Columns', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-posts-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Get available post types
     *
     * @return array
     */
    private function get_post_types() {
        $post_types = get_post_types( [ 'public' => true ], 'objects' );
        $options = [];

        foreach ( $post_types as $post_type ) {
            $options[ $post_type->name ] = $post_type->label;
        }

        return $options;
    }

    /**
     * Custom excerpt function
     *
     * @param int $length Excerpt length.
     * @return string
     */
    private function get_custom_excerpt( $length ) {
        $excerpt = get_the_excerpt();
        $excerpt = strip_shortcodes( $excerpt );
        $excerpt = strip_tags( $excerpt );
        $excerpt = substr( $excerpt, 0, $length );
        $excerpt = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
        $excerpt .= '...';
        
        return $excerpt;
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $args = [
            'post_type' => $settings['post_type'],
            'posts_per_page' => $settings['posts_per_page'],
        ];

        $query = new \WP_Query( $args );

        if ( $query->have_posts() ) :
            ?>
            <div class="custom-posts-grid">
                <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                    <div class="custom-post">
                        <?php if ( 'yes' === $settings['show_thumbnail'] && has_post_thumbnail() ) : ?>
                            <div class="custom-post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'medium' ); ?>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if ( 'yes' === $settings['show_title'] ) : ?>
                            <h3 class="custom-post-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h3>
                        <?php endif; ?>

                        <?php if ( 'yes' === $settings['show_excerpt'] ) : ?>
                            <div class="custom-post-excerpt">
                                <?php echo $this->get_custom_excerpt( $settings['excerpt_length'] ); ?>
                            </div>
                        <?php endif; ?>

                        <?php if ( 'yes' === $settings['show_read_more'] ) : ?>
                            <div class="custom-post-read-more-wrapper">
                                <a href="<?php the_permalink(); ?>" class="custom-post-read-more">
                                    <?php echo esc_html( $settings['read_more_text'] ); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
            <?php
            wp_reset_postdata();
        else :
            echo '<p>' . __( 'No posts found.', 'custom-elementor-widgets' ) . '</p>';
        endif;
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <div class="custom-posts-grid">
            <# for ( var i = 0; i < 3; i++ ) { #>
                <div class="custom-post">
                    <# if ( settings.show_thumbnail == 'yes' ) { #>
                        <div class="custom-post-thumbnail">
                            <a href="#">
                                <img src="<?php echo CUSTOM_ELEMENTOR_WIDGETS_URL . 'assets/img/placeholder.svg'; ?>" alt="Placeholder">
                            </a>
                        </div>
                    <# } #>

                    <# if ( settings.show_title == 'yes' ) { #>
                        <h3 class="custom-post-title">
                            <a href="#">Sample Post Title</a>
                        </h3>
                    <# } #>

                    <# if ( settings.show_excerpt == 'yes' ) { #>
                        <div class="custom-post-excerpt">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
                        </div>
                    <# } #>

                    <# if ( settings.show_read_more == 'yes' ) { #>
                        <div class="custom-post-read-more-wrapper">
                            <a href="#" class="custom-post-read-more">
                                {{{ settings.read_more_text }}}
                            </a>
                        </div>
                    <# } #>
                </div>
            <# } #>
        </div>
        <?php
    }
}
