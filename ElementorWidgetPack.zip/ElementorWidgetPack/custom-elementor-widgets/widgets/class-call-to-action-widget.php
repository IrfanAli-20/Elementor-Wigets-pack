<?php
/**
 * Call to Action Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Call to Action Widget Class
 */
class Call_To_Action_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_call_to_action';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Custom Call to Action', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-call-to-action';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Content', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'This is the Call to Action Title', 'custom-elementor-widgets' ),
                'placeholder' => __( 'Enter your title', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => __( 'Description', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'This is the Call to Action description. You can add your content here.', 'custom-elementor-widgets' ),
                'placeholder' => __( 'Enter your description', 'custom-elementor-widgets' ),
                'rows' => 10,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __( 'Button Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Click Here', 'custom-elementor-widgets' ),
                'placeholder' => __( 'Enter button text', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => __( 'Button Link', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'custom-elementor-widgets' ),
                'default' => [
                    'url' => '#',
                ],
                'show_external' => true,
            ]
        );

        $this->end_controls_section();

        // Layout Section
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __( 'Layout', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout',
            [
                'label' => __( 'Layout', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'centered',
                'options' => [
                    'centered' => __( 'Centered', 'custom-elementor-widgets' ),
                    'left' => __( 'Left Aligned', 'custom-elementor-widgets' ),
                    'right' => __( 'Right Aligned', 'custom-elementor-widgets' ),
                    'split' => __( 'Split', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'content_alignment',
            [
                'label' => __( 'Content Alignment', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-content' => 'text-align: {{VALUE}};',
                ],
                'condition' => [
                    'layout!' => 'split',
                ],
            ]
        );

        $this->add_responsive_control(
            'height',
            [
                'label' => __( 'Height', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh', 'em' ],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-container' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'show_image',
            [
                'label' => __( 'Background Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'background_image',
            [
                'label' => __( 'Choose Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Image_Size::get_type(),
            [
                'name' => 'background_image',
                'default' => 'large',
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'image_position',
            [
                'label' => __( 'Image Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'center center',
                'options' => [
                    'top left' => __( 'Top Left', 'custom-elementor-widgets' ),
                    'top center' => __( 'Top Center', 'custom-elementor-widgets' ),
                    'top right' => __( 'Top Right', 'custom-elementor-widgets' ),
                    'center left' => __( 'Center Left', 'custom-elementor-widgets' ),
                    'center center' => __( 'Center Center', 'custom-elementor-widgets' ),
                    'center right' => __( 'Center Right', 'custom-elementor-widgets' ),
                    'bottom left' => __( 'Bottom Left', 'custom-elementor-widgets' ),
                    'bottom center' => __( 'Bottom Center', 'custom-elementor-widgets' ),
                    'bottom right' => __( 'Bottom Right', 'custom-elementor-widgets' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-container' => 'background-position: {{VALUE}};',
                ],
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'overlay',
            [
                'label' => __( 'Overlay', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#f7f7f7',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-container' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'overlay_color',
            [
                'label' => __( 'Overlay Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.5)',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-overlay' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'overlay' => 'yes',
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'title_heading',
            [
                'label' => __( 'Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .custom-cta-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'description_heading',
            [
                'label' => __( 'Description', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .custom-cta-description',
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Description Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#777777',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_heading',
            [
                'label' => __( 'Button', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs( 'button_style_tabs' );

        $this->start_controls_tab(
            'button_normal_tab',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#61ce70',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .custom-cta-button',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#4bbb5a',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => __( 'Border Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-button:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_border_border!' => '',
                ],
            ]
        );

        $this->add_control(
            'button_hover_animation',
            [
                'label' => __( 'Hover Animation', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'button_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'button_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .custom-cta-button',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .custom-cta-button',
            ]
        );

        $this->end_controls_section();

        // Spacing Section
        $this->start_controls_section(
            'section_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Title Bottom Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Description Bottom Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-cta-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        // Get button URL
        $button_url = $settings['button_link']['url'] ? $settings['button_link']['url'] : '#';
        $button_target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
        $button_nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : '';
        
        // Get button animation class if set
        $button_animation = $settings['button_hover_animation'] ? 'elementor-animation-' . $settings['button_hover_animation'] : '';

        // Set layout class
        $layout_class = 'custom-cta-layout-' . $settings['layout'];

        // Set background image if enabled
        $background_style = '';
        if ( 'yes' === $settings['show_image'] && !empty( $settings['background_image']['url'] ) ) {
            $background_style = 'background-image: url(' . $settings['background_image']['url'] . '); background-size: cover; background-repeat: no-repeat;';
        }
        ?>
        <div class="custom-cta-container <?php echo esc_attr( $layout_class ); ?>" style="<?php echo esc_attr( $background_style ); ?>">
            <?php if ( 'yes' === $settings['show_image'] && 'yes' === $settings['overlay'] ) : ?>
                <div class="custom-cta-overlay"></div>
            <?php endif; ?>

            <div class="custom-cta-content">
                <?php if ( $settings['title'] ) : ?>
                    <h2 class="custom-cta-title"><?php echo esc_html( $settings['title'] ); ?></h2>
                <?php endif; ?>

                <?php if ( $settings['description'] ) : ?>
                    <div class="custom-cta-description"><?php echo wp_kses_post( $settings['description'] ); ?></div>
                <?php endif; ?>

                <?php if ( $settings['button_text'] ) : ?>
                    <div class="custom-cta-button-wrapper">
                        <a href="<?php echo esc_url( $button_url ); ?>" class="custom-cta-button <?php echo esc_attr( $button_animation ); ?>"<?php echo $button_target . $button_nofollow; ?>>
                            <?php echo esc_html( $settings['button_text'] ); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <#
        // Set layout class
        var layoutClass = 'custom-cta-layout-' + settings.layout;
        
        // Set background style if image is enabled
        var backgroundStyle = '';
        if ( 'yes' === settings.show_image && settings.background_image.url ) {
            backgroundStyle = 'background-image: url(' + settings.background_image.url + '); background-size: cover; background-repeat: no-repeat;';
        }
        
        // Get button animation class if set
        var buttonAnimation = settings.button_hover_animation ? 'elementor-animation-' + settings.button_hover_animation : '';
        
        // Get button URL and attributes
        var buttonUrl = settings.button_link.url ? settings.button_link.url : '#';
        var buttonTarget = settings.button_link.is_external ? ' target="_blank"' : '';
        var buttonNofollow = settings.button_link.nofollow ? ' rel="nofollow"' : '';
        #>
        <div class="custom-cta-container {{ layoutClass }}" style="{{{ backgroundStyle }}}">
            <# if ( 'yes' === settings.show_image && 'yes' === settings.overlay ) { #>
                <div class="custom-cta-overlay"></div>
            <# } #>

            <div class="custom-cta-content">
                <# if ( settings.title ) { #>
                    <h2 class="custom-cta-title">{{{ settings.title }}}</h2>
                <# } #>

                <# if ( settings.description ) { #>
                    <div class="custom-cta-description">{{{ settings.description }}}</div>
                <# } #>

                <# if ( settings.button_text ) { #>
                    <div class="custom-cta-button-wrapper">
                        <a href="{{ buttonUrl }}" class="custom-cta-button {{ buttonAnimation }}"{{{ buttonTarget }}}{{{ buttonNofollow }}}>
                            {{{ settings.button_text }}}
                        </a>
                    </div>
                <# } #>
            </div>
        </div>
        <?php
    }
}
