<?php
/**
 * Creative Buttons Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Creative Buttons Widget Class
 */
class Creative_Buttons_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_creative_buttons';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Creative Buttons', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-button';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'button', 'creative', 'link', 'cta', 'action' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Button Content', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'button_type',
            [
                'label' => __( 'Button Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'info',
                'options' => [
                    'info' => __( 'Info', 'custom-elementor-widgets' ),
                    'success' => __( 'Success', 'custom-elementor-widgets' ),
                    'warning' => __( 'Warning', 'custom-elementor-widgets' ),
                    'danger' => __( 'Danger', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __( 'Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Click Me', 'custom-elementor-widgets' ),
                'placeholder' => __( 'Enter your text', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => __( 'Link', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'custom-elementor-widgets' ),
                'default' => [
                    'url' => '#',
                ],
                'show_external' => true,
            ]
        );

        $this->add_control(
            'has_icon',
            [
                'label' => __( 'Icon', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __( 'Icon', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'condition' => [
                    'has_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => __( 'Icon Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __( 'Before', 'custom-elementor-widgets' ),
                    'after' => __( 'After', 'custom-elementor-widgets' ),
                ],
                'condition' => [
                    'has_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'icon_spacing',
            [
                'label' => __( 'Icon Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-button .button-icon-before' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .custom-button .button-icon-after' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'has_icon' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Button Style', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'button_style',
            [
                'label' => __( 'Button Style', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'solid',
                'options' => [
                    'solid' => __( 'Solid', 'custom-elementor-widgets' ),
                    'outline' => __( 'Outline', 'custom-elementor-widgets' ),
                    'gradient' => __( 'Gradient', 'custom-elementor-widgets' ),
                    '3d' => __( '3D', 'custom-elementor-widgets' ),
                    'shadow' => __( 'Shadow', 'custom-elementor-widgets' ),
                    'neon' => __( 'Neon', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'custom-button-style-',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'selector' => '{{WRAPPER}} .custom-button',
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_width',
            [
                'label' => __( 'Width', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-button' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_alignment',
            [
                'label' => __( 'Alignment', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .custom-button-wrapper' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'button_styles_tabs' );

        // Normal state tab
        $this->start_controls_tab(
            'button_normal_tab',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#61ce70',
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-solid .custom-button' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.custom-button-style-outline .custom-button' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}}.custom-button-style-shadow .custom-button' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.custom-button-style-3d .custom-button' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.custom-button-style-neon .custom-button' => 'border-color: {{VALUE}}; box-shadow: 0 0 10px {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color_two',
            [
                'label' => __( 'Background Color Two', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#3D8A58',
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-gradient .custom-button' => 'background-image: linear-gradient(to right, {{button_background_color.VALUE}} 0%, {{VALUE}} 100%);',
                ],
                'condition' => [
                    'button_style' => 'gradient',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .custom-button',
                'separator' => 'before',
                'condition' => [
                    'button_style!' => ['outline', 'neon'],
                ],
            ]
        );

        $this->add_control(
            'button_outline_width',
            [
                'label' => __( 'Outline Width', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-outline .custom-button' => 'border-width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.custom-button-style-neon .custom-button' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'button_style' => ['outline', 'neon'],
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .custom-button',
                'condition' => [
                    'button_style!' => ['shadow', 'neon'],
                ],
            ]
        );

        $this->add_control(
            'button_shadow_size',
            [
                'label' => __( 'Shadow Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-shadow .custom-button' => 'box-shadow: 0 {{SIZE}}{{UNIT}} 0 0 rgba(0, 0, 0, 0.2);',
                ],
                'condition' => [
                    'button_style' => 'shadow',
                ],
            ]
        );

        $this->add_control(
            'button_3d_depth',
            [
                'label' => __( '3D Depth', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-3d .custom-button' => 'box-shadow: 0 {{SIZE}}{{UNIT}} 0 0 rgba(0, 0, 0, 0.3); transform: translateY(0);',
                ],
                'condition' => [
                    'button_style' => '3d',
                ],
            ]
        );

        $this->add_control(
            'button_neon_glow',
            [
                'label' => __( 'Neon Glow Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-neon .custom-button' => 'box-shadow: 0 0 {{SIZE}}{{UNIT}} {{button_background_color.VALUE}};',
                ],
                'condition' => [
                    'button_style' => 'neon',
                ],
            ]
        );

        $this->end_controls_tab();

        // Hover state tab
        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#4bbb5a',
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-solid .custom-button:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.custom-button-style-outline .custom-button:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
                    '{{WRAPPER}}.custom-button-style-shadow .custom-button:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.custom-button-style-3d .custom-button:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.custom-button-style-neon .custom-button:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}}; box-shadow: 0 0 {{button_neon_glow.SIZE}}px {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background_color_two',
            [
                'label' => __( 'Background Color Two', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2D7546',
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-gradient .custom-button:hover' => 'background-image: linear-gradient(to right, {{button_hover_background_color.VALUE}} 0%, {{VALUE}} 100%);',
                ],
                'condition' => [
                    'button_style' => 'gradient',
                ],
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => __( 'Border Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-button:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_border_border!' => '',
                    'button_style!' => ['outline', 'neon'],
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_hover_box_shadow',
                'selector' => '{{WRAPPER}} .custom-button:hover',
                'condition' => [
                    'button_style!' => ['shadow', '3d', 'neon'],
                ],
            ]
        );

        $this->add_control(
            'button_hover_shadow_size',
            [
                'label' => __( 'Shadow Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-shadow .custom-button:hover' => 'box-shadow: 0 {{SIZE}}{{UNIT}} 0 0 rgba(0, 0, 0, 0.2);',
                ],
                'condition' => [
                    'button_style' => 'shadow',
                ],
            ]
        );

        $this->add_control(
            'button_hover_3d_depth',
            [
                'label' => __( 'Hover 3D Depth', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-3d .custom-button:hover' => 'box-shadow: 0 {{SIZE}}{{UNIT}} 0 0 rgba(0, 0, 0, 0.3); transform: translateY({{button_3d_transition.SIZE}}px);',
                ],
                'condition' => [
                    'button_style' => '3d',
                ],
            ]
        );

        $this->add_control(
            'button_3d_transition',
            [
                'label' => __( '3D Transition Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'default' => [
                    'size' => 4,
                ],
                'condition' => [
                    'button_style' => '3d',
                ],
            ]
        );

        $this->add_control(
            'button_hover_neon_glow',
            [
                'label' => __( 'Neon Hover Glow Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-style-neon .custom-button:hover' => 'box-shadow: 0 0 {{SIZE}}{{UNIT}} {{button_hover_background_color.VALUE}};',
                ],
                'condition' => [
                    'button_style' => 'neon',
                ],
            ]
        );

        $this->add_control(
            'button_hover_animation',
            [
                'label' => __( 'Hover Animation', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->add_control(
            'button_hover_transition',
            [
                'label' => __( 'Transition Duration', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.3,
                ],
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-button' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        // Effects Section
        $this->start_controls_section(
            'section_effects',
            [
                'label' => __( 'Special Effects', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'hover_effect',
            [
                'label' => __( 'Hover Effect', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __( 'None', 'custom-elementor-widgets' ),
                    'grow' => __( 'Grow', 'custom-elementor-widgets' ),
                    'shrink' => __( 'Shrink', 'custom-elementor-widgets' ),
                    'pulse' => __( 'Pulse', 'custom-elementor-widgets' ),
                    'pop' => __( 'Pop', 'custom-elementor-widgets' ),
                    'float' => __( 'Float', 'custom-elementor-widgets' ),
                    'wobble' => __( 'Wobble', 'custom-elementor-widgets' ),
                    'sweep' => __( 'Sweep', 'custom-elementor-widgets' ),
                    'ripple' => __( 'Ripple', 'custom-elementor-widgets' ),
                    'shine' => __( 'Shine', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'custom-button-effect-',
            ]
        );

        $this->add_control(
            'add_underline',
            [
                'label' => __( 'Add Underline Effect', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'button_style!' => 'outline',
                ],
                'prefix_class' => 'custom-button-underline-',
            ]
        );

        $this->add_control(
            'underline_color',
            [
                'label' => __( 'Underline Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}.custom-button-underline-yes .custom-button:after' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'add_underline' => 'yes',
                    'button_style!' => 'outline',
                ],
            ]
        );

        $this->add_control(
            'icon_hover_effect',
            [
                'label' => __( 'Icon Hover Effect', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __( 'None', 'custom-elementor-widgets' ),
                    'translate' => __( 'Translate', 'custom-elementor-widgets' ),
                    'rotate' => __( 'Rotate', 'custom-elementor-widgets' ),
                    'scale' => __( 'Scale', 'custom-elementor-widgets' ),
                    'bounce' => __( 'Bounce', 'custom-elementor-widgets' ),
                ],
                'condition' => [
                    'has_icon' => 'yes',
                ],
                'prefix_class' => 'custom-button-icon-effect-',
            ]
        );

        $this->add_control(
            'icon_translate_distance',
            [
                'label' => __( 'Icon Translate Distance', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-icon-effect-translate .custom-button:hover .button-icon-after' => 'transform: translateX({{SIZE}}{{UNIT}});',
                    '{{WRAPPER}}.custom-button-icon-effect-translate .custom-button:hover .button-icon-before' => 'transform: translateX(-{{SIZE}}{{UNIT}});',
                ],
                'condition' => [
                    'has_icon' => 'yes',
                    'icon_hover_effect' => 'translate',
                ],
            ]
        );

        $this->add_control(
            'icon_rotate_degrees',
            [
                'label' => __( 'Icon Rotate Degrees', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 360,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-icon-effect-rotate .custom-button:hover .button-icon' => 'transform: rotate({{SIZE}}deg);',
                ],
                'condition' => [
                    'has_icon' => 'yes',
                    'icon_hover_effect' => 'rotate',
                ],
            ]
        );

        $this->add_control(
            'icon_scale_factor',
            [
                'label' => __( 'Icon Scale Factor', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.5,
                        'max' => 2,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.custom-button-icon-effect-scale .custom-button:hover .button-icon' => 'transform: scale({{SIZE}});',
                ],
                'condition' => [
                    'has_icon' => 'yes',
                    'icon_hover_effect' => 'scale',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        // Build link attributes
        $link_url = ! empty( $settings['button_link']['url'] ) ? $settings['button_link']['url'] : '#';
        $target = ! empty( $settings['button_link']['is_external'] ) ? ' target="_blank"' : '';
        $nofollow = ! empty( $settings['button_link']['nofollow'] ) ? ' rel="nofollow"' : '';
        
        // Get button type class
        $button_type_class = 'custom-button-' . $settings['button_type'];
        
        // Get animation class
        $animation_class = ! empty( $settings['button_hover_animation'] ) ? 'elementor-animation-' . $settings['button_hover_animation'] : '';
        
        // Render
        ?>
        <div class="custom-button-wrapper">
            <a href="<?php echo esc_url( $link_url ); ?>" class="custom-button <?php echo esc_attr( $button_type_class . ' ' . $animation_class ); ?>"<?php echo $target . $nofollow; ?>>
                <?php if ( 'yes' === $settings['has_icon'] && 'before' === $settings['icon_position'] ) : ?>
                    <span class="button-icon button-icon-before">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    </span>
                <?php endif; ?>
                
                <span class="button-text"><?php echo esc_html( $settings['button_text'] ); ?></span>
                
                <?php if ( 'yes' === $settings['has_icon'] && 'after' === $settings['icon_position'] ) : ?>
                    <span class="button-icon button-icon-after">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    </span>
                <?php endif; ?>
            </a>
        </div>
        <?php
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <#
        // Build link attributes
        var link_url = settings.button_link.url ? settings.button_link.url : '#';
        var target = settings.button_link.is_external ? ' target="_blank"' : '';
        var nofollow = settings.button_link.nofollow ? ' rel="nofollow"' : '';
        
        // Get button type class
        var button_type_class = 'custom-button-' + settings.button_type;
        
        // Get animation class
        var animation_class = settings.button_hover_animation ? 'elementor-animation-' + settings.button_hover_animation : '';
        #>
        <div class="custom-button-wrapper">
            <a href="{{ link_url }}" class="custom-button {{ button_type_class }} {{ animation_class }}" {{{ target }}} {{{ nofollow }}}>
                <# if ( 'yes' === settings.has_icon && 'before' === settings.icon_position ) { #>
                    <span class="button-icon button-icon-before">
                        <# var iconHTML = elementor.helpers.renderIcon( view, settings.icon, { 'aria-hidden': true }, 'i' , 'object' ); #>
                        {{{ iconHTML.value }}}
                    </span>
                <# } #>
                
                <span class="button-text">{{{ settings.button_text }}}</span>
                
                <# if ( 'yes' === settings.has_icon && 'after' === settings.icon_position ) { #>
                    <span class="button-icon button-icon-after">
                        <# var iconHTML = elementor.helpers.renderIcon( view, settings.icon, { 'aria-hidden': true }, 'i' , 'object' ); #>
                        {{{ iconHTML.value }}}
                    </span>
                <# } #>
            </a>
        </div>
        <?php
    }
}
