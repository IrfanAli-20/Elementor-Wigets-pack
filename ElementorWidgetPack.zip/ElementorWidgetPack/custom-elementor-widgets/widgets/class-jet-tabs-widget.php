<?php
/**
 * JetTabs Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * JetTabs Widget Class
 */
class Jet_Tabs_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_jet_tabs';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'JetTabs', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-tabs';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'tabs', 'accordion', 'toggle', 'jet', 'jetpack' ];
    }

    /**
     * Register widget scripts.
     */
    public function get_script_depends() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget styles.
     */
    public function get_style_depends() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Tab Content Section
        $this->start_controls_section(
            'section_tabs',
            [
                'label' => __( 'Tabs', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'tab_layout',
            [
                'label' => __( 'Layout', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'horizontal',
                'options' => [
                    'horizontal' => __( 'Horizontal', 'custom-elementor-widgets' ),
                    'vertical' => __( 'Vertical', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'jet-tabs-layout-',
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_title',
            [
                'label' => __( 'Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Tab Title', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tab_icon',
            [
                'label' => __( 'Icon', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => '',
                    'library' => 'solid',
                ],
            ]
        );

        $repeater->add_control(
            'tab_content_type',
            [
                'label' => __( 'Content Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'content',
                'options' => [
                    'content' => __( 'Content', 'custom-elementor-widgets' ),
                    'template' => __( 'Elementor Template', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $repeater->add_control(
            'tab_content',
            [
                'label' => __( 'Content', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __( 'Tab Content', 'custom-elementor-widgets' ),
                'show_label' => false,
                'condition' => [
                    'tab_content_type' => 'content',
                ],
            ]
        );

        $repeater->add_control(
            'tab_template',
            [
                'label' => __( 'Choose Template', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => $this->get_elementor_templates(),
                'condition' => [
                    'tab_content_type' => 'template',
                ],
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label' => __( 'Tabs Items', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tab_title' => __( 'Tab #1', 'custom-elementor-widgets' ),
                        'tab_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'custom-elementor-widgets' ),
                        'tab_content_type' => 'content',
                    ],
                    [
                        'tab_title' => __( 'Tab #2', 'custom-elementor-widgets' ),
                        'tab_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'custom-elementor-widgets' ),
                        'tab_content_type' => 'content',
                    ],
                    [
                        'tab_title' => __( 'Tab #3', 'custom-elementor-widgets' ),
                        'tab_content' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'custom-elementor-widgets' ),
                        'tab_content_type' => 'content',
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );

        $this->add_control(
            'active_tab',
            [
                'label' => __( 'Active Tab Index', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
                'step' => 1,
                'default' => 1,
            ]
        );

        $this->end_controls_section();

        // Additional Features Section
        $this->start_controls_section(
            'section_features',
            [
                'label' => __( 'Features', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'tab_position',
            [
                'label' => __( 'Tab Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top' => __( 'Top', 'custom-elementor-widgets' ),
                    'bottom' => __( 'Bottom', 'custom-elementor-widgets' ),
                    'left' => __( 'Left', 'custom-elementor-widgets' ),
                    'right' => __( 'Right', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'jet-tabs-position-',
            ]
        );

        $this->add_control(
            'show_effect',
            [
                'label' => __( 'Show Effect', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __( 'Default', 'custom-elementor-widgets' ),
                    'fade' => __( 'Fade', 'custom-elementor-widgets' ),
                    'zoom-in' => __( 'Zoom In', 'custom-elementor-widgets' ),
                    'zoom-out' => __( 'Zoom Out', 'custom-elementor-widgets' ),
                    'move-up' => __( 'Move Up', 'custom-elementor-widgets' ),
                    'move-down' => __( 'Move Down', 'custom-elementor-widgets' ),
                    'move-right' => __( 'Move Right', 'custom-elementor-widgets' ),
                    'move-left' => __( 'Move Left', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'jet-tabs-effect-',
            ]
        );

        $this->add_control(
            'tabs_equal_height',
            [
                'label' => __( 'Equal Height', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => '',
                'prefix_class' => 'jet-tabs-equal-height-',
            ]
        );

        $this->add_control(
            'auto_switch',
            [
                'label' => __( 'Auto Switch', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'auto_switch_delay',
            [
                'label' => __( 'Auto Switch Delay (ms)', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3000,
                'min' => 500,
                'max' => 20000,
                'step' => 100,
                'condition' => [
                    'auto_switch' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'no_active_tabs',
            [
                'label' => __( 'No Active Tabs', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'tab_orientation',
            [
                'label' => __( 'Tab Orientation', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'horizontal',
                'options' => [
                    'horizontal' => __( 'Horizontal', 'custom-elementor-widgets' ),
                    'vertical' => __( 'Vertical', 'custom-elementor-widgets' ),
                ],
                'condition' => [
                    'tab_layout' => 'horizontal',
                ],
                'prefix_class' => 'jet-tabs-orientation-',
            ]
        );

        $this->end_controls_section();

        // Accordion Mode Section
        $this->start_controls_section(
            'section_accordion_mode',
            [
                'label' => __( 'Accordion Mode', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'accordion_mode',
            [
                'label' => __( 'Enable Accordion Mode', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => '',
                'prefix_class' => 'jet-tabs-accordion-',
            ]
        );

        $this->add_control(
            'accordion_collapse_others',
            [
                'label' => __( 'Collapse Others', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'accordion_mode' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'accordion_collapsible',
            [
                'label' => __( 'Collapsible', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'accordion_mode' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Tabs Style Section
        $this->start_controls_section(
            'section_tabs_style',
            [
                'label' => __( 'Tabs', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'tabs_alignment',
            [
                'label' => __( 'Tabs Alignment', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __( 'Left', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __( 'Right', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'stretch' => [
                        'title' => __( 'Justified', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-controls' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'tabs_width',
            [
                'label' => __( 'Tabs Width', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 50,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.jet-tabs-position-left .jet-tabs-controls' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.jet-tabs-position-right .jet-tabs-controls' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.jet-tabs-position-top .jet-tabs-control' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.jet-tabs-position-bottom .jet-tabs-control' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'tabs_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'tabs_margin',
            [
                'label' => __( 'Margin', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'tabs_typography',
                'label' => __( 'Typography', 'custom-elementor-widgets' ),
                'selector' => '{{WRAPPER}} .jet-tabs-control-inner',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'tabs_border',
                'label' => __( 'Border', 'custom-elementor-widgets' ),
                'selector' => '{{WRAPPER}} .jet-tabs-control',
            ]
        );

        $this->add_responsive_control(
            'tabs_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_style_tabs' );

        $this->start_controls_tab(
            'tabs_normal',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'tabs_background',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tabs_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control-inner' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Icon Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .jet-tabs-control-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tabs_hover',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'tabs_background_hover',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tabs_color_hover',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control:hover .jet-tabs-control-inner' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label' => __( 'Icon Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control:hover .jet-tabs-control-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .jet-tabs-control:hover .jet-tabs-control-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tabs_border_color_hover',
            [
                'label' => __( 'Border Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'tabs_border_border!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tabs_active',
            [
                'label' => __( 'Active', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'tabs_background_active',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control.active-tab' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tabs_color_active',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control.active-tab .jet-tabs-control-inner' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color_active',
            [
                'label' => __( 'Icon Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control.active-tab .jet-tabs-control-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .jet-tabs-control.active-tab .jet-tabs-control-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tabs_border_color_active',
            [
                'label' => __( 'Border Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => [
                    'tabs_border_border!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control.active-tab' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        // Content Style Section
        $this->start_controls_section(
            'section_content_style',
            [
                'label' => __( 'Content', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => __( 'Margin', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __( 'Typography', 'custom-elementor-widgets' ),
                'selector' => '{{WRAPPER}} .jet-tabs-content',
            ]
        );

        $this->add_control(
            'content_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'content_border',
                'label' => __( 'Border', 'custom-elementor-widgets' ),
                'selector' => '{{WRAPPER}} .jet-tabs-content',
            ]
        );

        $this->add_responsive_control(
            'content_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'content_box_shadow',
                'selector' => '{{WRAPPER}} .jet-tabs-content',
            ]
        );

        $this->end_controls_section();

        // Icon Style Section
        $this->start_controls_section(
            'section_icon_style',
            [
                'label' => __( 'Icon', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .jet-tabs-control-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_margin',
            [
                'label' => __( 'Margin', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .jet-tabs-control-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => __( 'Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' => __( 'Left', 'custom-elementor-widgets' ),
                    'right' => __( 'Right', 'custom-elementor-widgets' ),
                    'top' => __( 'Top', 'custom-elementor-widgets' ),
                ],
                'prefix_class' => 'jet-tabs-icon-position-',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Get Elementor templates.
     *
     * @return array Elementor templates array.
     */
    private function get_elementor_templates() {
        // This is a simplified version, in a real scenario you would query the database
        $templates = [
            '' => __( 'Select Template', 'custom-elementor-widgets' ),
            'template_1' => __( 'Template 1', 'custom-elementor-widgets' ),
            'template_2' => __( 'Template 2', 'custom-elementor-widgets' ),
        ];

        // In a real implementation, you might query for actual templates
        if ( class_exists( '\Elementor\Plugin' ) ) {
            $elementor = \Elementor\Plugin::instance();
            $templates_manager = $elementor->templates_manager;
            
            // Get templates if the method exists
            if ( method_exists( $templates_manager, 'get_source' ) ) {
                $source = $templates_manager->get_source( 'local' );
                if ( method_exists( $source, 'get_items' ) ) {
                    $template_items = $source->get_items();
                    
                    if ( !empty( $template_items ) ) {
                        $templates = ['' => __( 'Select Template', 'custom-elementor-widgets' )];
                        
                        foreach ( $template_items as $template ) {
                            $templates[$template['template_id']] = $template['title'];
                        }
                    }
                }
            }
        }
        
        return $templates;
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $id_int = substr( $this->get_id_int(), 0, 3 );
        $active_index = ( $settings['no_active_tabs'] !== 'yes' ) ? $settings['active_tab'] - 1 : -1;
        
        $this->add_render_attribute( 'wrapper', 'class', 'jet-tabs-wrapper' );
        
        if ( $settings['accordion_mode'] === 'yes' ) {
            $this->add_render_attribute( 'wrapper', 'data-accordion', 'true' );
            $this->add_render_attribute( 'wrapper', 'data-accordion-collapse-others', $settings['accordion_collapse_others'] );
            $this->add_render_attribute( 'wrapper', 'data-accordion-collapsible', $settings['accordion_collapsible'] );
        }
        
        if ( $settings['auto_switch'] === 'yes' ) {
            $this->add_render_attribute( 'wrapper', 'data-auto-switch', 'true' );
            $this->add_render_attribute( 'wrapper', 'data-auto-switch-delay', $settings['auto_switch_delay'] );
        }
        
        $this->add_render_attribute( 'wrapper', 'data-active-tab', $active_index );
        $this->add_render_attribute( 'wrapper', 'data-show-effect', $settings['show_effect'] );
        
        ?>
        <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
            <div class="jet-tabs-controls">
                <?php foreach ( $settings['tabs'] as $index => $item ) : 
                    $tab_count = $index + 1;
                    $tab_id = 'jet-tab-control-' . $id_int . $tab_count;
                    $content_id = 'jet-tab-content-' . $id_int . $tab_count;
                    
                    $tab_class = [ 'jet-tabs-control' ];
                    
                    if ( $active_index === $index ) {
                        $tab_class[] = 'active-tab';
                    }
                    
                    $this->add_render_attribute( 'tab-' . $tab_count, [
                        'id' => $tab_id,
                        'class' => $tab_class,
                        'data-tab' => $tab_count,
                        'aria-controls' => $content_id,
                        'role' => 'tab',
                        'tabindex' => $active_index === $index ? '0' : '-1',
                        'aria-selected' => $active_index === $index ? 'true' : 'false',
                    ] );
                ?>
                <div <?php echo $this->get_render_attribute_string( 'tab-' . $tab_count ); ?>>
                    <div class="jet-tabs-control-inner">
                        <?php if ( ! empty( $item['tab_icon'] ) && 'left' === $settings['icon_position'] ) : ?>
                            <div class="jet-tabs-control-icon"><?php \Elementor\Icons_Manager::render_icon( $item['tab_icon'], [ 'aria-hidden' => 'true' ] ); ?></div>
                        <?php endif; ?>
                        
                        <?php if ( 'top' === $settings['icon_position'] && ! empty( $item['tab_icon'] ) ) : ?>
                            <div class="jet-tabs-control-icon"><?php \Elementor\Icons_Manager::render_icon( $item['tab_icon'], [ 'aria-hidden' => 'true' ] ); ?></div>
                        <?php endif; ?>
                        
                        <div class="jet-tabs-control-title"><?php echo $item['tab_title']; ?></div>
                        
                        <?php if ( ! empty( $item['tab_icon'] ) && 'right' === $settings['icon_position'] ) : ?>
                            <div class="jet-tabs-control-icon"><?php \Elementor\Icons_Manager::render_icon( $item['tab_icon'], [ 'aria-hidden' => 'true' ] ); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="jet-tabs-content-wrapper">
                <?php foreach ( $settings['tabs'] as $index => $item ) : 
                    $tab_count = $index + 1;
                    $content_id = 'jet-tab-content-' . $id_int . $tab_count;
                    
                    $content_class = [ 'jet-tabs-content' ];
                    
                    if ( $active_index === $index ) {
                        $content_class[] = 'active-content';
                    }
                    
                    $this->add_render_attribute( 'content-' . $tab_count, [
                        'id' => $content_id,
                        'class' => $content_class,
                        'data-tab' => $tab_count,
                        'role' => 'tabpanel',
                        'aria-labelledby' => 'jet-tab-control-' . $id_int . $tab_count,
                        'tabindex' => $active_index === $index ? '0' : '-1',
                    ] );
                    
                    if ( $active_index !== $index ) {
                        $this->add_render_attribute( 'content-' . $tab_count, 'hidden', 'hidden' );
                    }
                ?>
                <div <?php echo $this->get_render_attribute_string( 'content-' . $tab_count ); ?>>
                    <?php if ( 'content' === $item['tab_content_type'] ) : ?>
                        <div class="jet-tabs-content-inner"><?php echo wp_kses_post( $item['tab_content'] ); ?></div>
                    <?php elseif ( 'template' === $item['tab_content_type'] && ! empty( $item['tab_template'] ) ) : ?>
                        <?php echo do_shortcode( '[elementor-template id="' . $item['tab_template'] . '"]' ); ?>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <#
        var idInt = view.getIDInt().substr( 0, 3 ),
            activeIndex = ( settings.no_active_tabs !== 'yes' ) ? settings.active_tab - 1 : -1,
            tabsData = [];
            
        view.addRenderAttribute( 'wrapper', 'class', 'jet-tabs-wrapper' );
            
        if ( 'yes' === settings.accordion_mode ) {
            view.addRenderAttribute( 'wrapper', 'data-accordion', 'true' );
            view.addRenderAttribute( 'wrapper', 'data-accordion-collapse-others', settings.accordion_collapse_others );
            view.addRenderAttribute( 'wrapper', 'data-accordion-collapsible', settings.accordion_collapsible );
        }
            
        if ( 'yes' === settings.auto_switch ) {
            view.addRenderAttribute( 'wrapper', 'data-auto-switch', 'true' );
            view.addRenderAttribute( 'wrapper', 'data-auto-switch-delay', settings.auto_switch_delay );
        }
            
        view.addRenderAttribute( 'wrapper', 'data-active-tab', activeIndex );
        view.addRenderAttribute( 'wrapper', 'data-show-effect', settings.show_effect );
        #>
        <div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
            <div class="jet-tabs-controls">
                <# _.each( settings.tabs, function( item, index ) {
                    var tabCount = index + 1,
                        tabId = 'jet-tab-control-' + idInt + tabCount,
                        contentId = 'jet-tab-content-' + idInt + tabCount,
                        tabClass = [ 'jet-tabs-control' ];
                        
                    if ( activeIndex === index ) {
                        tabClass.push( 'active-tab' );
                    }
                        
                    view.addRenderAttribute( 'tab-' + tabCount, {
                        'id': tabId,
                        'class': tabClass,
                        'data-tab': tabCount,
                        'aria-controls': contentId,
                        'role': 'tab',
                        'tabindex': activeIndex === index ? '0' : '-1',
                        'aria-selected': activeIndex === index ? 'true' : 'false',
                    } );
                #>
                <div {{{ view.getRenderAttributeString( 'tab-' + tabCount ) }}}>
                    <div class="jet-tabs-control-inner">
                        <# if ( item.tab_icon && 'left' === settings.icon_position ) { #>
                            <div class="jet-tabs-control-icon">
                                <# if ( item.tab_icon.value && typeof item.tab_icon.value === 'string' ) { #>
                                    <i class="{{ item.tab_icon.value }}"></i>
                                <# } #>
                            </div>
                        <# } #>
                        
                        <# if ( item.tab_icon && 'top' === settings.icon_position ) { #>
                            <div class="jet-tabs-control-icon">
                                <# if ( item.tab_icon.value && typeof item.tab_icon.value === 'string' ) { #>
                                    <i class="{{ item.tab_icon.value }}"></i>
                                <# } #>
                            </div>
                        <# } #>
                        
                        <div class="jet-tabs-control-title">{{{ item.tab_title }}}</div>
                        
                        <# if ( item.tab_icon && 'right' === settings.icon_position ) { #>
                            <div class="jet-tabs-control-icon">
                                <# if ( item.tab_icon.value && typeof item.tab_icon.value === 'string' ) { #>
                                    <i class="{{ item.tab_icon.value }}"></i>
                                <# } #>
                            </div>
                        <# } #>
                    </div>
                </div>
                <# } ); #>
            </div>
            
            <div class="jet-tabs-content-wrapper">
                <# _.each( settings.tabs, function( item, index ) {
                    var tabCount = index + 1,
                        contentId = 'jet-tab-content-' + idInt + tabCount,
                        contentClass = [ 'jet-tabs-content' ];
                        
                    if ( activeIndex === index ) {
                        contentClass.push( 'active-content' );
                    }
                        
                    view.addRenderAttribute( 'content-' + tabCount, {
                        'id': contentId,
                        'class': contentClass,
                        'data-tab': tabCount,
                        'role': 'tabpanel',
                        'aria-labelledby': 'jet-tab-control-' + idInt + tabCount,
                        'tabindex': activeIndex === index ? '0' : '-1',
                    } );
                        
                    if ( activeIndex !== index ) {
                        view.addRenderAttribute( 'content-' + tabCount, 'hidden', 'hidden' );
                    }
                #>
                <div {{{ view.getRenderAttributeString( 'content-' + tabCount ) }}}>
                    <# if ( 'content' === item.tab_content_type ) { #>
                        <div class="jet-tabs-content-inner">{{{ item.tab_content }}}</div>
                    <# } else if ( 'template' === item.tab_content_type && item.tab_template ) { #>
                        <div class="jet-tabs-template">Template content with ID: {{{ item.tab_template }}}</div>
                    <# } #>
                </div>
                <# } ); #>
            </div>
        </div>
        <?php
    }
}