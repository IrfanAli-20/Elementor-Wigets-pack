<?php
/**
 * Modal Popup Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Modal Popup Widget Class
 */
class Modal_Popup_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_modal_popup';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Modal Popup', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-popup-window';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'modal', 'popup', 'lightbox', 'dialog', 'window' ];
    }

    /**
     * Register widget scripts.
     */
    public function get_script_depends() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget styles.
     */
    public function get_style_depends() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Trigger Section
        $this->start_controls_section(
            'section_trigger',
            [
                'label' => __( 'Trigger', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'trigger_type',
            [
                'label' => __( 'Trigger Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'button',
                'options' => [
                    'button' => __( 'Button', 'custom-elementor-widgets' ),
                    'icon' => __( 'Icon', 'custom-elementor-widgets' ),
                    'image' => __( 'Image', 'custom-elementor-widgets' ),
                    'text' => __( 'Text', 'custom-elementor-widgets' ),
                    'page_load' => __( 'Page Load', 'custom-elementor-widgets' ),
                    'exit_intent' => __( 'Exit Intent', 'custom-elementor-widgets' ),
                    'scroll' => __( 'Scroll', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __( 'Button Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Open Modal', 'custom-elementor-widgets' ),
                'condition' => [
                    'trigger_type' => 'button',
                ],
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __( 'Icon', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-search',
                    'library' => 'solid',
                ],
                'condition' => [
                    'trigger_type' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => __( 'Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'trigger_type' => 'image',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium',
                'condition' => [
                    'trigger_type' => 'image',
                ],
            ]
        );

        $this->add_control(
            'text',
            [
                'label' => __( 'Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Click to Open', 'custom-elementor-widgets' ),
                'condition' => [
                    'trigger_type' => 'text',
                ],
            ]
        );

        $this->add_control(
            'delay',
            [
                'label' => __( 'Delay (ms)', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 2000,
                'min' => 0,
                'max' => 20000,
                'step' => 100,
                'condition' => [
                    'trigger_type' => 'page_load',
                ],
            ]
        );

        $this->add_control(
            'scroll_depth',
            [
                'label' => __( 'Scroll Depth (%)', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'default' => [
                    'size' => 50,
                ],
                'range' => [
                    '%' => [
                        'min' => 5,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'trigger_type' => 'scroll',
                ],
            ]
        );

        $this->add_control(
            'show_once',
            [
                'label' => __( 'Show Once', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'conditions' => [
                    'relation' => 'or',
                    'terms' => [
                        [
                            'name' => 'trigger_type',
                            'operator' => '==',
                            'value' => 'page_load',
                        ],
                        [
                            'name' => 'trigger_type',
                            'operator' => '==',
                            'value' => 'exit_intent',
                        ],
                        [
                            'name' => 'trigger_type',
                            'operator' => '==',
                            'value' => 'scroll',
                        ],
                    ],
                ],
            ]
        );

        $this->add_control(
            'cookie_expiry',
            [
                'label' => __( 'Cookie Expiry (days)', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 30,
                'min' => 1,
                'max' => 365,
                'condition' => [
                    'show_once' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Modal Content Section
        $this->start_controls_section(
            'section_modal_content',
            [
                'label' => __( 'Modal Content', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'content_type',
            [
                'label' => __( 'Content Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'content',
                'options' => [
                    'content' => __( 'Content', 'custom-elementor-widgets' ),
                    'template' => __( 'Elementor Template', 'custom-elementor-widgets' ),
                    'video' => __( 'Video', 'custom-elementor-widgets' ),
                    'image' => __( 'Image', 'custom-elementor-widgets' ),
                    'iframe' => __( 'iFrame', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'modal_title',
            [
                'label' => __( 'Modal Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Modal Title', 'custom-elementor-widgets' ),
                'condition' => [
                    'content_type' => 'content',
                ],
            ]
        );

        $this->add_control(
            'modal_content',
            [
                'label' => __( 'Modal Content', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __( 'Modal content goes here. You can add text, images, and other elements using the editor.', 'custom-elementor-widgets' ),
                'condition' => [
                    'content_type' => 'content',
                ],
            ]
        );

        $this->add_control(
            'template_id',
            [
                'label' => __( 'Choose Template', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $this->get_elementor_templates(),
                'condition' => [
                    'content_type' => 'template',
                ],
            ]
        );

        $this->add_control(
            'video_url',
            [
                'label' => __( 'Video URL', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://www.youtube.com/watch?v=XHOmBV4js_E', 'custom-elementor-widgets' ),
                'description' => __( 'YouTube or Vimeo URL', 'custom-elementor-widgets' ),
                'condition' => [
                    'content_type' => 'video',
                ],
            ]
        );

        $this->add_control(
            'modal_image',
            [
                'label' => __( 'Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'content_type' => 'image',
                ],
            ]
        );

        $this->add_control(
            'iframe_url',
            [
                'label' => __( 'iFrame URL', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://example.com', 'custom-elementor-widgets' ),
                'condition' => [
                    'content_type' => 'iframe',
                ],
            ]
        );

        $this->end_controls_section();

        // Modal Settings Section
        $this->start_controls_section(
            'section_modal_settings',
            [
                'label' => __( 'Modal Settings', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'modal_size',
            [
                'label' => __( 'Modal Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'medium',
                'options' => [
                    'small' => __( 'Small', 'custom-elementor-widgets' ),
                    'medium' => __( 'Medium', 'custom-elementor-widgets' ),
                    'large' => __( 'Large', 'custom-elementor-widgets' ),
                    'extra-large' => __( 'Extra Large', 'custom-elementor-widgets' ),
                    'custom' => __( 'Custom', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_responsive_control(
            'custom_width',
            [
                'label' => __( 'Custom Width', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'vw' ],
                'range' => [
                    'px' => [
                        'min' => 300,
                        'max' => 1200,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                    'vw' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 600,
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-content' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'modal_size' => 'custom',
                ],
            ]
        );

        $this->add_responsive_control(
            'custom_height',
            [
                'label' => __( 'Custom Height', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-content' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'modal_size' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'animation',
            [
                'label' => __( 'Animation', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'fade',
                'options' => [
                    'fade' => __( 'Fade', 'custom-elementor-widgets' ),
                    'slide' => __( 'Slide', 'custom-elementor-widgets' ),
                    'zoom' => __( 'Zoom', 'custom-elementor-widgets' ),
                    'swing' => __( 'Swing', 'custom-elementor-widgets' ),
                    'bounce' => __( 'Bounce', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'animation_speed',
            [
                'label' => __( 'Animation Speed (ms)', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 300,
                'min' => 100,
                'max' => 2000,
                'step' => 50,
            ]
        );

        $this->add_control(
            'overlay_click_close',
            [
                'label' => __( 'Close on Overlay Click', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'esc_close',
            [
                'label' => __( 'Close on ESC Key', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_close_button',
            [
                'label' => __( 'Show Close Button', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Trigger Style Section
        $this->start_controls_section(
            'section_trigger_style',
            [
                'label' => __( 'Trigger Style', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'trigger_type!' => ['page_load', 'exit_intent', 'scroll'],
                ],
            ]
        );

        $this->add_control(
            'trigger_align',
            [
                'label' => __( 'Alignment', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-container' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'trigger_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'trigger_type' => 'button',
                ],
            ]
        );

        // Button Trigger Tabs
        $this->start_controls_tabs(
            'trigger_button_style_tabs',
            [
                'condition' => [
                    'trigger_type' => 'button',
                ],
            ]
        );

        $this->start_controls_tab(
            'trigger_button_normal_tab',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#6ec1e4',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'trigger_button_hover_tab',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#23a455',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-btn:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Icon Style
        $this->add_control(
            'icon_size',
            [
                'label' => __( 'Icon Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 300,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'trigger_type' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Icon Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#6ec1e4',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-icon i' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'trigger_type' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'icon_hover_color',
            [
                'label' => __( 'Icon Hover Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#23a455',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-icon i:hover' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'trigger_type' => 'icon',
                ],
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#6ec1e4',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-text' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'trigger_type' => 'text',
                ],
            ]
        );

        $this->add_control(
            'text_hover_color',
            [
                'label' => __( 'Text Hover Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#23a455',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-trigger-text:hover' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'trigger_type' => 'text',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'selector' => '{{WRAPPER}} .custom-modal-trigger-text',
                'condition' => [
                    'trigger_type' => 'text',
                ],
            ]
        );

        $this->end_controls_section();

        // Modal Style Section
        $this->start_controls_section(
            'section_modal_style',
            [
                'label' => __( 'Modal Style', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'modal_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'overlay_background_color',
            [
                'label' => __( 'Overlay Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.8)',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-overlay' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'modal_border',
                'selector' => '{{WRAPPER}} .custom-modal-content',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'modal_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'modal_box_shadow',
                'selector' => '{{WRAPPER}} .custom-modal-content',
            ]
        );

        $this->add_responsive_control(
            'modal_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-content-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'modal_title_heading',
            [
                'label' => __( 'Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'content_type' => 'content',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#333333',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-title' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'content_type' => 'content',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .custom-modal-title',
                'condition' => [
                    'content_type' => 'content',
                ],
            ]
        );

        $this->add_control(
            'modal_content_heading',
            [
                'label' => __( 'Content', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'content_type' => 'content',
                ],
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#7a7a7a',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-body' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'content_type' => 'content',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .custom-modal-body',
                'condition' => [
                    'content_type' => 'content',
                ],
            ]
        );

        $this->add_control(
            'close_button_heading',
            [
                'label' => __( 'Close Button', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_close_button' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'close_button_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#7a7a7a',
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-close' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_close_button' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'close_button_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 80,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-modal-close' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_close_button' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Get Elementor templates.
     *
     * @return array Elementor templates array.
     */
    private function get_elementor_templates() {
        // This is a simplified version, in a real scenario you would query the database
        $templates = [
            '' => __( 'Select Template', 'custom-elementor-widgets' ),
            'template_1' => __( 'Template 1', 'custom-elementor-widgets' ),
            'template_2' => __( 'Template 2', 'custom-elementor-widgets' ),
        ];

        // In a real implementation, you might query for actual templates
        if ( class_exists( '\Elementor\Plugin' ) ) {
            $elementor = \Elementor\Plugin::instance();
            $templates_manager = $elementor->templates_manager;
            
            // Get templates if the method exists
            if ( method_exists( $templates_manager, 'get_source' ) ) {
                $source = $templates_manager->get_source( 'local' );
                if ( method_exists( $source, 'get_items' ) ) {
                    $template_items = $source->get_items();
                    
                    if ( !empty( $template_items ) ) {
                        $templates = ['' => __( 'Select Template', 'custom-elementor-widgets' )];
                        
                        foreach ( $template_items as $template ) {
                            $templates[$template['template_id']] = $template['title'];
                        }
                    }
                }
            }
        }
        
        return $templates;
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $modal_id = 'custom-modal-' . $this->get_id();
        
        echo '<div class="custom-modal-wrapper">';
        
        // Render Trigger based on type
        if ( in_array( $settings['trigger_type'], ['button', 'icon', 'image', 'text'] ) ) {
            echo '<div class="custom-modal-trigger-container">';
            
            if ( 'button' === $settings['trigger_type'] ) {
                echo '<button class="custom-modal-trigger-btn" data-modal="' . esc_attr( $modal_id ) . '">' . esc_html( $settings['button_text'] ) . '</button>';
            } elseif ( 'icon' === $settings['trigger_type'] ) {
                echo '<div class="custom-modal-trigger-icon" data-modal="' . esc_attr( $modal_id ) . '">';
                \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] );
                echo '</div>';
            } elseif ( 'image' === $settings['trigger_type'] ) {
                echo '<div class="custom-modal-trigger-image" data-modal="' . esc_attr( $modal_id ) . '">';
                echo \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'image' );
                echo '</div>';
            } else { // text
                echo '<span class="custom-modal-trigger-text" data-modal="' . esc_attr( $modal_id ) . '">' . esc_html( $settings['text'] ) . '</span>';
            }
            
            echo '</div>';
        }
        
        // Render Modal
        echo '<div id="' . esc_attr( $modal_id ) . '" class="custom-modal modal-size-' . esc_attr( $settings['modal_size'] ) . '" style="display: none;">';
        echo '<div class="custom-modal-overlay"></div>';
        echo '<div class="custom-modal-content">';
        
        if ( 'yes' === $settings['show_close_button'] ) {
            echo '<span class="custom-modal-close"><i class="fas fa-times"></i></span>';
        }
        
        echo '<div class="custom-modal-content-inner">';
        
        // Render content based on type
        if ( 'content' === $settings['content_type'] ) {
            if ( !empty( $settings['modal_title'] ) ) {
                echo '<h3 class="custom-modal-title">' . esc_html( $settings['modal_title'] ) . '</h3>';
            }
            echo '<div class="custom-modal-body">' . wp_kses_post( $settings['modal_content'] ) . '</div>';
        } elseif ( 'template' === $settings['content_type'] && !empty( $settings['template_id'] ) ) {
            // In real implementation, you would render the template here
            echo '<div class="custom-modal-template">';
            echo do_shortcode( '[elementor-template id="' . esc_attr( $settings['template_id'] ) . '"]' );
            echo '</div>';
        } elseif ( 'video' === $settings['content_type'] && !empty( $settings['video_url']['url'] ) ) {
            echo '<div class="custom-modal-video">';
            // In real implementation, you would use a video embedding function
            echo 'Video would be embedded here from: ' . esc_url( $settings['video_url']['url'] );
            echo '</div>';
        } elseif ( 'image' === $settings['content_type'] ) {
            echo '<div class="custom-modal-image">';
            echo \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'full', 'modal_image' );
            echo '</div>';
        } elseif ( 'iframe' === $settings['content_type'] && !empty( $settings['iframe_url']['url'] ) ) {
            echo '<div class="custom-modal-iframe">';
            echo '<iframe src="' . esc_url( $settings['iframe_url']['url'] ) . '" frameborder="0" allowfullscreen></iframe>';
            echo '</div>';
        }
        
        echo '</div>'; // End content inner
        echo '</div>'; // End content
        echo '</div>'; // End modal
        
        echo '</div>'; // End wrapper
        
        // Non-trigger settings via data attributes
        if ( in_array( $settings['trigger_type'], ['page_load', 'exit_intent', 'scroll'] ) ) {
            echo '<script type="text/javascript">';
            echo 'document.addEventListener("DOMContentLoaded", function() {';
            echo 'var modalSettings = {';
            echo '"modalId": "' . esc_attr( $modal_id ) . '",';
            echo '"triggerType": "' . esc_attr( $settings['trigger_type'] ) . '",';
            
            if ( 'page_load' === $settings['trigger_type'] ) {
                echo '"delay": ' . esc_attr( $settings['delay'] ) . ',';
            } elseif ( 'scroll' === $settings['trigger_type'] ) {
                echo '"scrollDepth": ' . esc_attr( $settings['scroll_depth']['size'] ) . ',';
            }
            
            echo '"showOnce": ' . ( 'yes' === $settings['show_once'] ? 'true' : 'false' ) . ',';
            echo '"cookieExpiry": ' . esc_attr( $settings['cookie_expiry'] ) . ',';
            echo '"overlayClose": ' . ( 'yes' === $settings['overlay_click_close'] ? 'true' : 'false' ) . ',';
            echo '"escClose": ' . ( 'yes' === $settings['esc_close'] ? 'true' : 'false' ) . ',';
            echo '"animation": "' . esc_attr( $settings['animation'] ) . '",';
            echo '"animationSpeed": ' . esc_attr( $settings['animation_speed'] );
            echo '};';
            
            // This would be replaced with actual JavaScript that initializes the modal
            echo 'console.log("Modal initialized with settings:", modalSettings);';
            echo '});';
            echo '</script>';
        }
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <div class="custom-modal-wrapper">
            <# 
            var modalId = 'custom-modal-id';
            
            // Render Trigger based on type
            if ( ['button', 'icon', 'image', 'text'].indexOf(settings.trigger_type) >= 0 ) { 
            #>
                <div class="custom-modal-trigger-container">
                    <# if ( 'button' === settings.trigger_type ) { #>
                        <button class="custom-modal-trigger-btn" data-modal="{{ modalId }}">{{ settings.button_text }}</button>
                    <# } else if ( 'icon' === settings.trigger_type ) { #>
                        <div class="custom-modal-trigger-icon" data-modal="{{ modalId }}">
                            <i class="{{ settings.icon.value }}"></i>
                        </div>
                    <# } else if ( 'image' === settings.trigger_type ) { #>
                        <div class="custom-modal-trigger-image" data-modal="{{ modalId }}">
                            <img src="{{ settings.image.url }}" alt="Modal Trigger">
                        </div>
                    <# } else { #>
                        <span class="custom-modal-trigger-text" data-modal="{{ modalId }}">{{ settings.text }}</span>
                    <# } #>
                </div>
            <# } #>
            
            <# // Render Modal #>
            <div id="{{ modalId }}" class="custom-modal modal-size-{{ settings.modal_size }}" style="display: none;">
                <div class="custom-modal-overlay"></div>
                <div class="custom-modal-content">
                    <# if ( 'yes' === settings.show_close_button ) { #>
                        <span class="custom-modal-close"><i class="fas fa-times"></i></span>
                    <# } #>
                    
                    <div class="custom-modal-content-inner">
                        <# // Render content based on type #>
                        <# if ( 'content' === settings.content_type ) { #>
                            <# if ( settings.modal_title ) { #>
                                <h3 class="custom-modal-title">{{ settings.modal_title }}</h3>
                            <# } #>
                            <div class="custom-modal-body">{{{ settings.modal_content }}}</div>
                        <# } else if ( 'template' === settings.content_type && settings.template_id ) { #>
                            <div class="custom-modal-template">
                                Template #{{ settings.template_id }} would be rendered here
                            </div>
                        <# } else if ( 'video' === settings.content_type && settings.video_url.url ) { #>
                            <div class="custom-modal-video">
                                Video would be embedded here from: {{ settings.video_url.url }}
                            </div>
                        <# } else if ( 'image' === settings.content_type ) { #>
                            <div class="custom-modal-image">
                                <img src="{{ settings.modal_image.url }}" alt="Modal Content">
                            </div>
                        <# } else if ( 'iframe' === settings.content_type && settings.iframe_url.url ) { #>
                            <div class="custom-modal-iframe">
                                <iframe src="{{ settings.iframe_url.url }}" frameborder="0" allowfullscreen></iframe>
                            </div>
                        <# } #>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}