<?php
/**
 * Forms Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Forms Widget Class
 */
class Forms_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_forms';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Custom Forms', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        // Form Fields Section
        $this->start_controls_section(
            'section_form_fields',
            [
                'label' => __( 'Form Fields', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'form_title',
            [
                'label' => __( 'Form Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Contact Us', 'custom-elementor-widgets' ),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'field_type',
            [
                'label' => __( 'Field Type', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'text',
                'options' => [
                    'text' => __( 'Text', 'custom-elementor-widgets' ),
                    'email' => __( 'Email', 'custom-elementor-widgets' ),
                    'textarea' => __( 'Textarea', 'custom-elementor-widgets' ),
                    'select' => __( 'Select', 'custom-elementor-widgets' ),
                    'checkbox' => __( 'Checkbox', 'custom-elementor-widgets' ),
                    'radio' => __( 'Radio', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $repeater->add_control(
            'field_label',
            [
                'label' => __( 'Field Label', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Field Label', 'custom-elementor-widgets' ),
            ]
        );

        $repeater->add_control(
            'field_name',
            [
                'label' => __( 'Field Name', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'field_name', 'custom-elementor-widgets' ),
            ]
        );

        $repeater->add_control(
            'field_placeholder',
            [
                'label' => __( 'Field Placeholder', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Enter your value', 'custom-elementor-widgets' ),
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'field_type',
                            'operator' => 'in',
                            'value' => [
                                'text',
                                'email',
                                'textarea',
                                'select',
                            ],
                        ],
                    ],
                ],
            ]
        );

        $repeater->add_control(
            'field_required',
            [
                'label' => __( 'Required', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $repeater->add_control(
            'field_options',
            [
                'label' => __( 'Options', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( "Option 1\nOption 2\nOption 3", 'custom-elementor-widgets' ),
                'description' => __( 'Enter each option in a new line', 'custom-elementor-widgets' ),
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'field_type',
                            'operator' => 'in',
                            'value' => [
                                'select',
                                'checkbox',
                                'radio',
                            ],
                        ],
                    ],
                ],
            ]
        );

        $this->add_control(
            'form_fields',
            [
                'label' => __( 'Form Fields', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'field_type' => 'text',
                        'field_label' => __( 'Name', 'custom-elementor-widgets' ),
                        'field_name' => 'name',
                        'field_placeholder' => __( 'Enter your name', 'custom-elementor-widgets' ),
                        'field_required' => 'yes',
                    ],
                    [
                        'field_type' => 'email',
                        'field_label' => __( 'Email', 'custom-elementor-widgets' ),
                        'field_name' => 'email',
                        'field_placeholder' => __( 'Enter your email', 'custom-elementor-widgets' ),
                        'field_required' => 'yes',
                    ],
                    [
                        'field_type' => 'textarea',
                        'field_label' => __( 'Message', 'custom-elementor-widgets' ),
                        'field_name' => 'message',
                        'field_placeholder' => __( 'Enter your message', 'custom-elementor-widgets' ),
                        'field_required' => 'yes',
                    ],
                ],
                'title_field' => '{{{ field_label }}}',
            ]
        );

        $this->add_control(
            'submit_button_text',
            [
                'label' => __( 'Submit Button Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Submit', 'custom-elementor-widgets' ),
            ]
        );

        $this->end_controls_section();

        // Form Settings Section
        $this->start_controls_section(
            'section_form_settings',
            [
                'label' => __( 'Form Settings', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'form_id',
            [
                'label' => __( 'Form ID', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'custom_form', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'form_action',
            [
                'label' => __( 'Form Action URL', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => __( 'Enter form action URL', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'form_method',
            [
                'label' => __( 'Form Method', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'post',
                'options' => [
                    'post' => __( 'POST', 'custom-elementor-widgets' ),
                    'get' => __( 'GET', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'success_message',
            [
                'label' => __( 'Success Message', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Your message has been sent successfully!', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'error_message',
            [
                'label' => __( 'Error Message', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'There was an error sending your message. Please try again later.', 'custom-elementor-widgets' ),
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'form_title_heading',
            [
                'label' => __( 'Form Title', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'form_title_typography',
                'selector' => '{{WRAPPER}} .custom-form-title',
            ]
        );

        $this->add_control(
            'form_title_color',
            [
                'label' => __( 'Title Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .custom-form-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'form_fields_heading',
            [
                'label' => __( 'Form Fields', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'form_label_typography',
                'label' => __( 'Label Typography', 'custom-elementor-widgets' ),
                'selector' => '{{WRAPPER}} .custom-form-field label',
            ]
        );

        $this->add_control(
            'form_label_color',
            [
                'label' => __( 'Label Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .custom-form-field label' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'form_field_padding',
            [
                'label' => __( 'Input Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-form-field input, {{WRAPPER}} .custom-form-field textarea, {{WRAPPER}} .custom-form-field select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'form_field_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-form-field input, {{WRAPPER}} .custom-form-field textarea, {{WRAPPER}} .custom-form-field select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'submit_button_heading',
            [
                'label' => __( 'Submit Button', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'submit_button_typography',
                'selector' => '{{WRAPPER}} .custom-form-submit-button',
            ]
        );

        $this->start_controls_tabs( 'submit_button_style_tabs' );

        $this->start_controls_tab(
            'submit_button_normal_tab',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'submit_button_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#61ce70',
                'selectors' => [
                    '{{WRAPPER}} .custom-form-submit-button' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'submit_button_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-form-submit-button' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'submit_button_hover_tab',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'submit_button_hover_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#4bbb5a',
                'selectors' => [
                    '{{WRAPPER}} .custom-form-submit-button:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'submit_button_hover_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-form-submit-button:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'submit_button_padding',
            [
                'label' => __( 'Button Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-form-submit-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'submit_button_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-form-submit-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $form_id = $settings['form_id'];
        ?>
        <div class="custom-form-wrapper">
            <?php if ( ! empty( $settings['form_title'] ) ) : ?>
                <h3 class="custom-form-title"><?php echo esc_html( $settings['form_title'] ); ?></h3>
            <?php endif; ?>

            <form id="<?php echo esc_attr( $form_id ); ?>" class="custom-form" method="<?php echo esc_attr( $settings['form_method'] ); ?>" action="<?php echo esc_url( $settings['form_action'] ); ?>">
                <?php
                foreach ( $settings['form_fields'] as $item ) :
                    $field_id = $form_id . '_' . $item['field_name'];
                    $required = 'yes' === $item['field_required'] ? 'required' : '';
                    ?>
                    <div class="custom-form-field custom-form-field-<?php echo esc_attr( $item['field_type'] ); ?>">
                        <label for="<?php echo esc_attr( $field_id ); ?>">
                            <?php echo esc_html( $item['field_label'] ); ?>
                            <?php if ( 'yes' === $item['field_required'] ) : ?>
                                <span class="required">*</span>
                            <?php endif; ?>
                        </label>

                        <?php if ( 'text' === $item['field_type'] || 'email' === $item['field_type'] ) : ?>
                            <input 
                                type="<?php echo esc_attr( $item['field_type'] ); ?>"
                                id="<?php echo esc_attr( $field_id ); ?>"
                                name="<?php echo esc_attr( $item['field_name'] ); ?>"
                                placeholder="<?php echo esc_attr( $item['field_placeholder'] ); ?>"
                                <?php echo $required; ?>
                            >
                        <?php elseif ( 'textarea' === $item['field_type'] ) : ?>
                            <textarea
                                id="<?php echo esc_attr( $field_id ); ?>"
                                name="<?php echo esc_attr( $item['field_name'] ); ?>"
                                placeholder="<?php echo esc_attr( $item['field_placeholder'] ); ?>"
                                <?php echo $required; ?>
                            ></textarea>
                        <?php elseif ( 'select' === $item['field_type'] ) : ?>
                            <select
                                id="<?php echo esc_attr( $field_id ); ?>"
                                name="<?php echo esc_attr( $item['field_name'] ); ?>"
                                <?php echo $required; ?>
                            >
                                <option value=""><?php echo esc_html( $item['field_placeholder'] ); ?></option>
                                <?php
                                $options = explode( PHP_EOL, $item['field_options'] );
                                foreach ( $options as $option ) {
                                    $option = trim( $option );
                                    if ( ! empty( $option ) ) {
                                        echo '<option value="' . esc_attr( $option ) . '">' . esc_html( $option ) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        <?php elseif ( 'checkbox' === $item['field_type'] ) : ?>
                            <?php
                            $options = explode( PHP_EOL, $item['field_options'] );
                            foreach ( $options as $index => $option ) {
                                $option = trim( $option );
                                if ( ! empty( $option ) ) {
                                    $checkbox_id = $field_id . '_' . $index;
                                    ?>
                                    <div class="checkbox-item">
                                        <input
                                            type="checkbox"
                                            id="<?php echo esc_attr( $checkbox_id ); ?>"
                                            name="<?php echo esc_attr( $item['field_name'] ); ?>[]"
                                            value="<?php echo esc_attr( $option ); ?>"
                                        >
                                        <label for="<?php echo esc_attr( $checkbox_id ); ?>"><?php echo esc_html( $option ); ?></label>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        <?php elseif ( 'radio' === $item['field_type'] ) : ?>
                            <?php
                            $options = explode( PHP_EOL, $item['field_options'] );
                            foreach ( $options as $index => $option ) {
                                $option = trim( $option );
                                if ( ! empty( $option ) ) {
                                    $radio_id = $field_id . '_' . $index;
                                    ?>
                                    <div class="radio-item">
                                        <input
                                            type="radio"
                                            id="<?php echo esc_attr( $radio_id ); ?>"
                                            name="<?php echo esc_attr( $item['field_name'] ); ?>"
                                            value="<?php echo esc_attr( $option ); ?>"
                                            <?php echo $required; ?>
                                        >
                                        <label for="<?php echo esc_attr( $radio_id ); ?>"><?php echo esc_html( $option ); ?></label>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <div class="custom-form-field custom-form-submit">
                    <button type="submit" class="custom-form-submit-button"><?php echo esc_html( $settings['submit_button_text'] ); ?></button>
                </div>
            </form>

            <div class="custom-form-message" style="display: none;"></div>

            <script>
            jQuery(document).ready(function($) {
                $('#<?php echo esc_attr( $form_id ); ?>').on('submit', function(e) {
                    e.preventDefault();
                    
                    var form = $(this);
                    var formData = form.serialize();
                    var messageContainer = form.siblings('.custom-form-message');
                    
                    $.ajax({
                        url: form.attr('action') || '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>',
                        type: form.attr('method') || 'post',
                        data: formData + '&action=custom_form_submission',
                        beforeSend: function() {
                            form.find('.custom-form-submit-button').prop('disabled', true);
                        },
                        success: function(response) {
                            if (response.success) {
                                messageContainer.html('<?php echo esc_js( $settings['success_message'] ); ?>').addClass('success').removeClass('error').show();
                                form[0].reset();
                            } else {
                                messageContainer.html('<?php echo esc_js( $settings['error_message'] ); ?>').addClass('error').removeClass('success').show();
                            }
                        },
                        error: function() {
                            messageContainer.html('<?php echo esc_js( $settings['error_message'] ); ?>').addClass('error').removeClass('success').show();
                        },
                        complete: function() {
                            form.find('.custom-form-submit-button').prop('disabled', false);
                        }
                    });
                });
            });
            </script>
        </div>
        <?php
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <div class="custom-form-wrapper">
            <# if ( settings.form_title ) { #>
                <h3 class="custom-form-title">{{{ settings.form_title }}}</h3>
            <# } #>
            
            <form id="{{ settings.form_id }}" class="custom-form" method="{{ settings.form_method }}" action="{{ settings.form_action }}">
                <# _.each( settings.form_fields, function( item, index ) { 
                    var fieldId = settings.form_id + '_' + item.field_name;
                    var required = 'yes' === item.field_required ? 'required' : '';
                #>
                    <div class="custom-form-field custom-form-field-{{ item.field_type }}">
                        <label for="{{ fieldId }}">
                            {{{ item.field_label }}}
                            <# if ( 'yes' === item.field_required ) { #>
                                <span class="required">*</span>
                            <# } #>
                        </label>
                        
                        <# if ( 'text' === item.field_type || 'email' === item.field_type ) { #>
                            <input 
                                type="{{ item.field_type }}" 
                                id="{{ fieldId }}" 
                                name="{{ item.field_name }}" 
                                placeholder="{{ item.field_placeholder }}" 
                                {{{ required }}}
                            >
                        <# } else if ( 'textarea' === item.field_type ) { #>
                            <textarea 
                                id="{{ fieldId }}" 
                                name="{{ item.field_name }}" 
                                placeholder="{{ item.field_placeholder }}" 
                                {{{ required }}}
                            ></textarea>
                        <# } else if ( 'select' === item.field_type ) { #>
                            <select 
                                id="{{ fieldId }}" 
                                name="{{ item.field_name }}" 
                                {{{ required }}}
                            >
                                <option value="">{{ item.field_placeholder }}</option>
                                <# 
                                if ( item.field_options ) {
                                    var options = item.field_options.split('\n');
                                    _.each( options, function( option ) {
                                        option = option.trim();
                                        if ( option ) {
                                #>
                                            <option value="{{ option }}">{{ option }}</option>
                                <#
                                        }
                                    });
                                }
                                #>
                            </select>
                        <# } else if ( 'checkbox' === item.field_type ) { #>
                            <# 
                            if ( item.field_options ) {
                                var options = item.field_options.split('\n');
                                _.each( options, function( option, optionIndex ) {
                                    option = option.trim();
                                    if ( option ) {
                                        var checkboxId = fieldId + '_' + optionIndex;
                            #>
                                        <div class="checkbox-item">
                                            <input 
                                                type="checkbox" 
                                                id="{{ checkboxId }}" 
                                                name="{{ item.field_name }}[]" 
                                                value="{{ option }}"
                                            >
                                            <label for="{{ checkboxId }}">{{ option }}</label>
                                        </div>
                            <#
                                    }
                                });
                            }
                            #>
                        <# } else if ( 'radio' === item.field_type ) { #>
                            <# 
                            if ( item.field_options ) {
                                var options = item.field_options.split('\n');
                                _.each( options, function( option, optionIndex ) {
                                    option = option.trim();
                                    if ( option ) {
                                        var radioId = fieldId + '_' + optionIndex;
                            #>
                                        <div class="radio-item">
                                            <input 
                                                type="radio" 
                                                id="{{ radioId }}" 
                                                name="{{ item.field_name }}" 
                                                value="{{ option }}"
                                                {{{ required }}}
                                            >
                                            <label for="{{ radioId }}">{{ option }}</label>
                                        </div>
                            <#
                                    }
                                });
                            }
                            #>
                        <# } #>
                    </div>
                <# }); #>
                
                <div class="custom-form-field custom-form-submit">
                    <button type="submit" class="custom-form-submit-button">{{{ settings.submit_button_text }}}</button>
                </div>
            </form>
            
            <div class="custom-form-message" style="display: none;"></div>
        </div>
        <?php
    }
}
