<?php
/**
 * Slides Widget
 *
 * @package CustomElementorWidgets
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Slides Widget Class
 */
class Slides_Widget extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'custom_slides';
    }

    /**
     * Get widget title.
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Custom Slides', 'custom-elementor-widgets' );
    }

    /**
     * Get widget icon.
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-slides';
    }

    /**
     * Get widget categories.
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Get widget keywords.
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'slides', 'carousel', 'slider', 'slideshow' ];
    }

    /**
     * Register widget scripts.
     */
    public function get_script_depends() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget styles.
     */
    public function get_style_depends() {
        return [ 'custom-elementor-widgets' ];
    }

    /**
     * Register widget controls.
     */
    protected function register_controls() {
        $this->start_controls_section(
            'section_slides',
            [
                'label' => __( 'Slides', 'custom-elementor-widgets' ),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'slide_heading',
            [
                'label' => __( 'Heading', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Slide Heading', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'slide_description',
            [
                'label' => __( 'Description', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'I am a slide description. Click edit button to change this text.', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'slide_button_text',
            [
                'label' => __( 'Button Text', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Click Here', 'custom-elementor-widgets' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'slide_button_link',
            [
                'label' => __( 'Button Link', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'custom-elementor-widgets' ),
                'default' => [
                    'url' => '#',
                ],
                'condition' => [
                    'slide_button_text!' => '',
                ],
            ]
        );

        $repeater->add_control(
            'slide_background_image',
            [
                'label' => __( 'Background Image', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'slide_background_overlay',
            [
                'label' => __( 'Background Overlay', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'custom-elementor-widgets' ),
                'label_off' => __( 'Hide', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
            'slide_background_overlay_color',
            [
                'label' => __( 'Overlay Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, 0.5)',
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .custom-slide-overlay' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'slide_background_overlay' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'slide_content_alignment',
            [
                'label' => __( 'Content Alignment', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'custom-elementor-widgets' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .custom-slide-content' => 'text-align: {{VALUE}}',
                ],
            ]
        );

        $repeater->add_control(
            'slide_content_position',
            [
                'label' => __( 'Content Position', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'middle',
                'options' => [
                    'top' => __( 'Top', 'custom-elementor-widgets' ),
                    'middle' => __( 'Middle', 'custom-elementor-widgets' ),
                    'bottom' => __( 'Bottom', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'slides',
            [
                'label' => __( 'Slides', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'slide_heading' => __( 'First Slide Heading', 'custom-elementor-widgets' ),
                        'slide_description' => __( 'I am slide content. Click edit button to change this text.', 'custom-elementor-widgets' ),
                        'slide_button_text' => __( 'Click Here', 'custom-elementor-widgets' ),
                        'slide_background_overlay' => 'yes',
                        'slide_content_alignment' => 'center',
                        'slide_content_position' => 'middle',
                    ],
                    [
                        'slide_heading' => __( 'Second Slide Heading', 'custom-elementor-widgets' ),
                        'slide_description' => __( 'I am slide content. Click edit button to change this text.', 'custom-elementor-widgets' ),
                        'slide_button_text' => __( 'Click Here', 'custom-elementor-widgets' ),
                        'slide_background_overlay' => 'yes',
                        'slide_content_alignment' => 'center',
                        'slide_content_position' => 'middle',
                    ],
                ],
                'title_field' => '{{{ slide_heading }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_slider_settings',
            [
                'label' => __( 'Slider Settings', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'navigation',
            [
                'label' => __( 'Navigation', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'both',
                'options' => [
                    'both' => __( 'Arrows and Dots', 'custom-elementor-widgets' ),
                    'arrows' => __( 'Arrows', 'custom-elementor-widgets' ),
                    'dots' => __( 'Dots', 'custom-elementor-widgets' ),
                    'none' => __( 'None', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __( 'Autoplay', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __( 'Autoplay Speed', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'infinite',
            [
                'label' => __( 'Infinite Loop', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'transition',
            [
                'label' => __( 'Transition', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'slide',
                'options' => [
                    'slide' => __( 'Slide', 'custom-elementor-widgets' ),
                    'fade' => __( 'Fade', 'custom-elementor-widgets' ),
                ],
            ]
        );

        $this->add_control(
            'transition_speed',
            [
                'label' => __( 'Transition Speed', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 500,
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label' => __( 'Pause on Hover', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'custom-elementor-widgets' ),
                'label_off' => __( 'No', 'custom-elementor-widgets' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_slider',
            [
                'label' => __( 'Slider', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'slider_height',
            [
                'label' => __( 'Height', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 400,
                    'unit' => 'px',
                ],
                'size_units' => [ 'px', 'vh' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-slider, {{WRAPPER}} .custom-slide' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'slide_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_content',
            [
                'label' => __( 'Content', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'heading_style',
            [
                'label' => __( 'Heading', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'selector' => '{{WRAPPER}} .custom-slide-heading',
            ]
        );

        $this->add_control(
            'heading_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-heading' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'heading_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-heading' => 'margin-bottom: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'description_style',
            [
                'label' => __( 'Description', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .custom-slide-description',
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-description' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Spacing', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-description' => 'margin-bottom: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'button_style',
            [
                'label' => __( 'Button', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs( 'button_styles' );

        $this->start_controls_tab(
            'button_normal',
            [
                'label' => __( 'Normal', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-button' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#61ce70',
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-button' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .custom-slide-button',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover',
            [
                'label' => __( 'Hover', 'custom-elementor-widgets' ),
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label' => __( 'Text Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-button:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background_color',
            [
                'label' => __( 'Background Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#4bbb5a',
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-button:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => __( 'Border Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-button:hover' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'button_border_border!' => '',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'button_border_radius',
            [
                'label' => __( 'Border Radius', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'button_padding',
            [
                'label' => __( 'Padding', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .custom-slide-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .custom-slide-button',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_navigation',
            [
                'label' => __( 'Navigation', 'custom-elementor-widgets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'navigation!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'heading_arrows',
            [
                'label' => __( 'Arrows', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'navigation' => [ 'arrows', 'both' ],
                ],
            ]
        );

        $this->add_control(
            'arrows_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-slider-prev, {{WRAPPER}} .custom-slider-next' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'navigation' => [ 'arrows', 'both' ],
                ],
            ]
        );

        $this->add_control(
            'arrows_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-slider-prev, {{WRAPPER}} .custom-slider-next' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation' => [ 'arrows', 'both' ],
                ],
            ]
        );

        $this->add_control(
            'heading_dots',
            [
                'label' => __( 'Dots', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'navigation' => [ 'dots', 'both' ],
                ],
            ]
        );

        $this->add_control(
            'dots_size',
            [
                'label' => __( 'Size', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .custom-slider-dots .custom-slider-dot' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'navigation' => [ 'dots', 'both' ],
                ],
            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label' => __( 'Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .custom-slider-dots .custom-slider-dot' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation' => [ 'dots', 'both' ],
                ],
            ]
        );

        $this->add_control(
            'dots_active_color',
            [
                'label' => __( 'Active Color', 'custom-elementor-widgets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#61ce70',
                'selectors' => [
                    '{{WRAPPER}} .custom-slider-dots .custom-slider-dot.active' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation' => [ 'dots', 'both' ],
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render widget output on the frontend.
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $this->add_render_attribute( 'slider', 'class', 'custom-slider' );
        $this->add_render_attribute( 'slider', 'data-autoplay', $settings['autoplay'] );
        $this->add_render_attribute( 'slider', 'data-autoplay-speed', $settings['autoplay_speed'] );
        $this->add_render_attribute( 'slider', 'data-infinite', $settings['infinite'] );
        $this->add_render_attribute( 'slider', 'data-transition', $settings['transition'] );
        $this->add_render_attribute( 'slider', 'data-transition-speed', $settings['transition_speed'] );
        $this->add_render_attribute( 'slider', 'data-pause-on-hover', $settings['pause_on_hover'] );
        
        $show_arrows = in_array( $settings['navigation'], [ 'arrows', 'both' ] );
        $show_dots = in_array( $settings['navigation'], [ 'dots', 'both' ] );
        
        if ( empty( $settings['slides'] ) ) {
            return;
        }
        ?>
        <div class="custom-slider-wrapper">
            <div <?php echo $this->get_render_attribute_string( 'slider' ); ?>>
                <div class="custom-slider-container">
                    <?php foreach ( $settings['slides'] as $index => $slide ) : ?>
                        <?php 
                        $slide_class = 'custom-slide elementor-repeater-item-' . $slide['_id'];
                        $slide_content_class = 'custom-slide-content custom-slide-content-' . $slide['slide_content_position'];
                        
                        $this->add_render_attribute( 'slide-' . $index, 'class', $slide_class );
                        $this->add_render_attribute( 'slide-content-' . $index, 'class', $slide_content_class );
                        
                        $button_url = ! empty( $slide['slide_button_link']['url'] ) ? $slide['slide_button_link']['url'] : '#';
                        $button_target = ! empty( $slide['slide_button_link']['is_external'] ) ? ' target="_blank"' : '';
                        $button_nofollow = ! empty( $slide['slide_button_link']['nofollow'] ) ? ' rel="nofollow"' : '';
                        ?>
                        
                        <div <?php echo $this->get_render_attribute_string( 'slide-' . $index ); ?>>
                            <div class="custom-slide-background" style="background-image: url('<?php echo esc_url( $slide['slide_background_image']['url'] ); ?>'); background-size: cover; background-position: center;">
                                <?php if ( 'yes' === $slide['slide_background_overlay'] ) : ?>
                                    <div class="custom-slide-overlay"></div>
                                <?php endif; ?>
                            </div>
                            
                            <div <?php echo $this->get_render_attribute_string( 'slide-content-' . $index ); ?>>
                                <?php if ( ! empty( $slide['slide_heading'] ) ) : ?>
                                    <h2 class="custom-slide-heading"><?php echo esc_html( $slide['slide_heading'] ); ?></h2>
                                <?php endif; ?>
                                
                                <?php if ( ! empty( $slide['slide_description'] ) ) : ?>
                                    <div class="custom-slide-description"><?php echo wp_kses_post( $slide['slide_description'] ); ?></div>
                                <?php endif; ?>
                                
                                <?php if ( ! empty( $slide['slide_button_text'] ) ) : ?>
                                    <a class="custom-slide-button" href="<?php echo esc_url( $button_url ); ?>"<?php echo $button_target . $button_nofollow; ?>>
                                        <?php echo esc_html( $slide['slide_button_text'] ); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <?php if ( $show_arrows ) : ?>
                    <div class="custom-slider-nav">
                        <button class="custom-slider-prev" aria-label="<?php echo esc_attr__( 'Previous', 'custom-elementor-widgets' ); ?>">
                            <i class="eicon-chevron-left" aria-hidden="true"></i>
                        </button>
                        <button class="custom-slider-next" aria-label="<?php echo esc_attr__( 'Next', 'custom-elementor-widgets' ); ?>">
                            <i class="eicon-chevron-right" aria-hidden="true"></i>
                        </button>
                    </div>
                <?php endif; ?>
                
                <?php if ( $show_dots ) : ?>
                    <div class="custom-slider-dots">
                        <?php foreach ( $settings['slides'] as $index => $slide ) : ?>
                            <span class="custom-slider-dot<?php echo 0 === $index ? ' active' : ''; ?>" data-slide="<?php echo esc_attr( $index ); ?>"></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render widget output in the editor.
     */
    protected function content_template() {
        ?>
        <#
        var showArrows = ['arrows', 'both'].indexOf(settings.navigation) !== -1;
        var showDots = ['dots', 'both'].indexOf(settings.navigation) !== -1;
        #>
        <div class="custom-slider-wrapper">
            <div class="custom-slider" 
                data-autoplay="{{ settings.autoplay }}"
                data-autoplay-speed="{{ settings.autoplay_speed }}"
                data-infinite="{{ settings.infinite }}"
                data-transition="{{ settings.transition }}"
                data-transition-speed="{{ settings.transition_speed }}"
                data-pause-on-hover="{{ settings.pause_on_hover }}">
                
                <div class="custom-slider-container">
                    <# _.each( settings.slides, function( slide, index ) { 
                        var slideClass = 'custom-slide elementor-repeater-item-' + slide._id;
                        var slideContentClass = 'custom-slide-content custom-slide-content-' + slide.slide_content_position;
                        
                        var buttonUrl = slide.slide_button_link.url ? slide.slide_button_link.url : '#';
                        var buttonTarget = slide.slide_button_link.is_external ? ' target="_blank"' : '';
                        var buttonNofollow = slide.slide_button_link.nofollow ? ' rel="nofollow"' : '';
                    #>
                        <div class="{{ slideClass }}">
                            <div class="custom-slide-background" style="background-image: url('{{ slide.slide_background_image.url }}'); background-size: cover; background-position: center;">
                                <# if ( 'yes' === slide.slide_background_overlay ) { #>
                                    <div class="custom-slide-overlay"></div>
                                <# } #>
                            </div>
                            
                            <div class="{{ slideContentClass }}">
                                <# if ( slide.slide_heading ) { #>
                                    <h2 class="custom-slide-heading">{{{ slide.slide_heading }}}</h2>
                                <# } #>
                                
                                <# if ( slide.slide_description ) { #>
                                    <div class="custom-slide-description">{{{ slide.slide_description }}}</div>
                                <# } #>
                                
                                <# if ( slide.slide_button_text ) { #>
                                    <a class="custom-slide-button" href="{{ buttonUrl }}"{{{ buttonTarget }}}{{{ buttonNofollow }}}>
                                        {{{ slide.slide_button_text }}}
                                    </a>
                                <# } #>
                            </div>
                        </div>
                    <# }); #>
                </div>
                
                <# if ( showArrows ) { #>
                    <div class="custom-slider-nav">
                        <button class="custom-slider-prev" aria-label="Previous">
                            <i class="eicon-chevron-left" aria-hidden="true"></i>
                        </button>
                        <button class="custom-slider-next" aria-label="Next">
                            <i class="eicon-chevron-right" aria-hidden="true"></i>
                        </button>
                    </div>
                <# } #>
                
                <# if ( showDots ) { #>
                    <div class="custom-slider-dots">
                        <# _.each( settings.slides, function( slide, index ) { #>
                            <span class="custom-slider-dot<# if ( index === 0 ) { #> active<# } #>" data-slide="{{ index }}"></span>
                        <# }); #>
                    </div>
                <# } #>
            </div>
        </div>
        <?php
    }
}
