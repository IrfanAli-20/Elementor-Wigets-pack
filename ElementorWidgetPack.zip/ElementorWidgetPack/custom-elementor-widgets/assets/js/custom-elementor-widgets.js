/**
 * Custom Elementor Widgets - JavaScript
 *
 * This file contains all the interactive functionality for custom elementor widgets
 * Includes accessibility features for improved user experience
 */

(function($) {
    'use strict';

    /**
     * A11y Helper Functions
     */
    const a11yHelpers = {
        // Focus trap for modal dialogs
        trapFocus: function(element) {
            const focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
            const firstFocusableElement = element.querySelectorAll(focusableElements)[0];
            const focusableContent = element.querySelectorAll(focusableElements);
            const lastFocusableElement = focusableContent[focusableContent.length - 1];

            // Set focus on first element
            requestAnimationFrame(() => {
                firstFocusableElement.focus();
            });

            element.addEventListener('keydown', function(e) {
                let isTabPressed = e.key === 'Tab' || e.keyCode === 9;

                if (!isTabPressed) {
                    return;
                }

                if (e.shiftKey) { // Shift + Tab
                    if (document.activeElement === firstFocusableElement) {
                        lastFocusableElement.focus();
                        e.preventDefault();
                    }
                } else { // Tab
                    if (document.activeElement === lastFocusableElement) {
                        firstFocusableElement.focus();
                        e.preventDefault();
                    }
                }
            });
        },

        // Handle ESC key for modal dialogs
        handleEscKey: function(element, closeCallback) {
            element.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' || e.keyCode === 27) {
                    closeCallback();
                }
            });
        },

        // Make elements keyboard navigable
        makeKeyboardNavigable: function(container, itemSelector, activationCallback) {
            const items = container.querySelectorAll(itemSelector);
            
            items.forEach((item, index) => {
                // Make sure item is focusable
                if (!item.getAttribute('tabindex')) {
                    item.setAttribute('tabindex', '0');
                }
                
                // Add keyboard event
                item.addEventListener('keydown', function(e) {
                    // Enter or Space
                    if (e.key === 'Enter' || e.key === ' ' || e.keyCode === 13 || e.keyCode === 32) {
                        e.preventDefault();
                        activationCallback(index, item);
                    }
                });
            });
        },

        // Ensure proper ARIA attributes
        setAriaAttributes: function(element, attributes) {
            for (const key in attributes) {
                element.setAttribute(key, attributes[key]);
            }
        },
        
        // Announce message to screen readers
        announceToScreenReader: function(message) {
            const announce = document.getElementById('custom-elementor-a11y-announce');
            
            if (!announce) {
                const announceElement = document.createElement('div');
                announceElement.setAttribute('id', 'custom-elementor-a11y-announce');
                announceElement.setAttribute('role', 'alert');
                announceElement.setAttribute('aria-live', 'assertive');
                announceElement.style.position = 'absolute';
                announceElement.style.width = '1px';
                announceElement.style.height = '1px';
                announceElement.style.padding = '0';
                announceElement.style.margin = '-1px';
                announceElement.style.overflow = 'hidden';
                announceElement.style.clip = 'rect(0, 0, 0, 0)';
                announceElement.style.whiteSpace = 'nowrap';
                announceElement.style.border = '0';
                document.body.appendChild(announceElement);
            }
            
            document.getElementById('custom-elementor-a11y-announce').textContent = message;
        }
    };

    /**
     * Initialize all widgets when Elementor frontend is loaded
     */
    $(window).on('elementor/frontend/init', function() {
        // Initialize each widget
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_posts.default', initPostsWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_forms.default', initFormsWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_call_to_action.default', initCallToActionWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_slides.default', initSlidesWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_advanced_post_grid.default', initAdvancedPostGridWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_creative_buttons.default', initCreativeButtonsWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_interactive_testimonials.default', initInteractiveTestimonialsWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_info_box.default', initInfoBoxWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_modal_popup.default', initModalPopupWidget);
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_jet_tabs.default', initJetTabsWidget);
    });

    /**
     * Initialize Posts Widget
     */
    function initPostsWidget($scope) {
        // Any posts widget specific initialization code
        console.log('Posts Widget Initialized');
    }

    /**
     * Initialize Forms Widget
     */
    function initFormsWidget($scope) {
        const $form = $scope.find('form.custom-form');

        if ($form.length) {
            // Add accessibility enhancements for form fields
            enhanceFormAccessibility($form);
            
            $form.on('submit', function(e) {
                e.preventDefault();

                // Validate form before submission with accessible error messages
                if (!validateFormAccessibly($form)) {
                    return;
                }

                // Get form data
                const formData = new FormData(this);
                const $submitButton = $form.find('.custom-form-submit-button');
                const $message = $form.find('.custom-form-message');

                // Show loading state with ARIA attributes
                $submitButton.prop('disabled', true)
                    .text('Sending...')
                    .attr('aria-busy', 'true');
                
                // Add loading announcement for screen readers
                a11yHelpers.announceToScreenReader('Submitting form, please wait...');

                // For demo purposes - simulate form submission
                setTimeout(function() {
                    // In a real implementation, this would be an AJAX request to the server
                    const successMessage = $form.data('success-message') || 'Form submitted successfully';
                    
                    // Add ARIA live region for success message
                    $message.attr('aria-live', 'assertive')
                        .html('<div class="custom-form-success" role="status">' + successMessage + '</div>')
                        .show();
                    
                    // Announce to screen readers
                    a11yHelpers.announceToScreenReader(successMessage);
                    
                    // Reset button state
                    $submitButton.prop('disabled', false)
                        .text('Submit')
                        .attr('aria-busy', 'false');
                    
                    // Reset form
                    $form[0].reset();
                    
                    // Focus back to a sensible location
                    $form.find('input').first().focus();
                }, 1000);
            });
        }

        /**
         * Enhance form fields with accessibility attributes
         */
        function enhanceFormAccessibility($form) {
            // Add proper labeling
            $form.find('.custom-form-field').each(function() {
                const $field = $(this);
                const $label = $field.find('label');
                const $input = $field.find('input, textarea, select');
                
                // Skip if already set up
                if ($input.attr('id') && $label.attr('for')) {
                    return;
                }
                
                // Create unique ID if needed
                if (!$input.attr('id')) {
                    const fieldType = $input.attr('type') || $input.prop('tagName').toLowerCase();
                    const uniqueId = 'form-' + fieldType + '-' + Math.floor(Math.random() * 1000000);
                    $input.attr('id', uniqueId);
                    
                    // Connect label to input
                    if ($label.length) {
                        $label.attr('for', uniqueId);
                    }
                }
                
                // Add ARIA attributes for required fields
                if ($input.attr('required')) {
                    $input.attr('aria-required', 'true');
                    
                    // Add visual indication in the label
                    if ($label.length && !$label.find('.required-indicator').length) {
                        $label.append('<span class="required-indicator" aria-hidden="true"> *</span>');
                    }
                }
                
                // Add descriptive text for screen readers if needed
                const placeholder = $input.attr('placeholder');
                if (placeholder && !$input.attr('aria-describedby')) {
                    const descId = $input.attr('id') + '-desc';
                    $field.append('<span id="' + descId + '" class="screen-reader-text">' + placeholder + '</span>');
                    $input.attr('aria-describedby', descId);
                }
            });
            
            // Add role to the form
            if (!$form.attr('role')) {
                $form.attr('role', 'form');
            }
            
            // Set up the submission button
            const $submitButton = $form.find('.custom-form-submit-button');
            if ($submitButton.length) {
                if (!$submitButton.attr('type')) {
                    $submitButton.attr('type', 'submit');
                }
            }
            
            // Set up error container for form validation
            if (!$form.find('.custom-form-errors').length) {
                $form.prepend('<div class="custom-form-errors" aria-live="assertive" role="alert"></div>');
            }
        }
        
        /**
         * Validate form with accessible error messages
         */
        function validateFormAccessibly($form) {
            const $errorContainer = $form.find('.custom-form-errors');
            let isValid = true;
            let errorMessages = [];
            
            // Clear previous errors
            $errorContainer.empty().hide();
            $form.find('.custom-form-field').removeClass('has-error');
            $form.find('.field-error-message').remove();
            
            // Check each required field
            $form.find('[required]').each(function() {
                const $input = $(this);
                const $field = $input.closest('.custom-form-field');
                const fieldName = $field.find('label').text().replace('*', '').trim() || $input.attr('name') || 'Field';
                
                if (!$input.val().trim()) {
                    isValid = false;
                    
                    // Add error class
                    $field.addClass('has-error');
                    
                    // Add field-specific error message
                    const errorId = $input.attr('id') + '-error';
                    $field.append('<div id="' + errorId + '" class="field-error-message">' + fieldName + ' is required</div>');
                    
                    // Connect input to the error message with aria-describedby
                    $input.attr('aria-invalid', 'true')
                          .attr('aria-describedby', ($input.attr('aria-describedby') || '') + ' ' + errorId);
                    
                    errorMessages.push(fieldName + ' is required');
                } else {
                    // Field is valid
                    $input.attr('aria-invalid', 'false');
                }
                
                // Add more validation for specific field types (email, etc.)
                if ($input.attr('type') === 'email' && $input.val().trim() && !validateEmail($input.val())) {
                    isValid = false;
                    $field.addClass('has-error');
                    
                    const errorId = $input.attr('id') + '-error';
                    $field.append('<div id="' + errorId + '" class="field-error-message">Please enter a valid email address</div>');
                    
                    $input.attr('aria-invalid', 'true')
                          .attr('aria-describedby', ($input.attr('aria-describedby') || '') + ' ' + errorId);
                    
                    errorMessages.push('Please enter a valid email address for ' + fieldName);
                }
            });
            
            // If we have errors, display them
            if (!isValid) {
                // Add summary message to the top
                $errorContainer.html('<p>Please fix the following errors:</p><ul>' + 
                    errorMessages.map(msg => '<li>' + msg + '</li>').join('') + 
                    '</ul>').show();
                
                // Announce to screen readers
                a11yHelpers.announceToScreenReader('Form has ' + errorMessages.length + ' errors. Please fix them and try again.');
                
                // Focus the first field with an error
                $form.find('.has-error input, .has-error textarea, .has-error select').first().focus();
            }
            
            return isValid;
        }
        
        /**
         * Validate email format
         */
        function validateEmail(email) {
            const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(String(email).toLowerCase());
        }

        console.log('Forms Widget Initialized with Accessibility Features');
    }

    /**
     * Initialize Call To Action Widget
     */
    function initCallToActionWidget($scope) {
        // Any CTA widget specific initialization code
        console.log('Call To Action Widget Initialized');
    }

    /**
     * Initialize Slides Widget
     */
    function initSlidesWidget($scope) {
        const $slider = $scope.find('.custom-slider');
        
        if ($slider.length) {
            // Get slider settings
            const settings = $slider.data('settings') || {};
            const defaults = {
                arrows: true,
                dots: true,
                infinite: true,
                speed: 500,
                autoplay: true,
                autoplaySpeed: 5000,
                slidesToShow: 1,
                slidesToScroll: 1,
                fade: true,
                pauseOnHover: true
            };
            
            // Merge defaults with settings
            const sliderSettings = $.extend({}, defaults, settings);
            
            // Initialize slider
            // For a real implementation, you would use a library like Slick
            console.log('Slider initialized with settings:', sliderSettings);
            
            // Simple slider functionality for demonstration
            let currentSlide = 0;
            const $slides = $slider.find('.custom-slide');
            const slideCount = $slides.length;
            
            // Initially hide all slides except the first one
            $slides.hide().eq(currentSlide).show();
            
            // Handle navigation dots
            const $dotsContainer = $('<div class="custom-slider-dots"></div>');
            $slider.append($dotsContainer);
            
            for (let i = 0; i < slideCount; i++) {
                const $dot = $('<div class="custom-slider-dot"></div>');
                if (i === currentSlide) {
                    $dot.addClass('active');
                }
                $dot.data('slide', i);
                $dotsContainer.append($dot);
            }
            
            // Handle navigation arrows
            const $navContainer = $('<div class="custom-slider-navigation"></div>');
            const $prevButton = $('<div class="custom-slider-arrow custom-slider-arrow-prev"><i class="fas fa-chevron-left"></i></div>');
            const $nextButton = $('<div class="custom-slider-arrow custom-slider-arrow-next"><i class="fas fa-chevron-right"></i></div>');
            
            $navContainer.append($prevButton).append($nextButton);
            $slider.append($navContainer);
            
            // Click handlers
            $dotsContainer.on('click', '.custom-slider-dot', function() {
                const slideIndex = $(this).data('slide');
                goToSlide(slideIndex);
            });
            
            $prevButton.on('click', function() {
                goToSlide((currentSlide - 1 + slideCount) % slideCount);
            });
            
            $nextButton.on('click', function() {
                goToSlide((currentSlide + 1) % slideCount);
            });
            
            // Function to change slide
            function goToSlide(index) {
                // Hide current slide
                $slides.eq(currentSlide).fadeOut(300);
                
                // Update current slide
                currentSlide = index;
                
                // Show new slide
                $slides.eq(currentSlide).fadeIn(300);
                
                // Update active dot
                $dotsContainer.find('.custom-slider-dot').removeClass('active').eq(currentSlide).addClass('active');
            }
            
            // Autoplay
            if (sliderSettings.autoplay) {
                let slideInterval = setInterval(function() {
                    goToSlide((currentSlide + 1) % slideCount);
                }, sliderSettings.autoplaySpeed);
                
                // Pause on hover
                if (sliderSettings.pauseOnHover) {
                    $slider.hover(
                        function() {
                            clearInterval(slideInterval);
                        },
                        function() {
                            slideInterval = setInterval(function() {
                                goToSlide((currentSlide + 1) % slideCount);
                            }, sliderSettings.autoplaySpeed);
                        }
                    );
                }
            }
        }
        
        console.log('Slides Widget Initialized');
    }

    /**
     * Initialize Advanced Post Grid Widget
     */
    function initAdvancedPostGridWidget($scope) {
        const $grid = $scope.find('.custom-advanced-post-grid');
        const $filterButtons = $scope.find('.custom-post-filter-button');
        const $loadMoreButton = $scope.find('.custom-post-load-more');
        
        // Filter functionality
        if ($filterButtons.length) {
            $filterButtons.on('click', function() {
                const filterValue = $(this).data('filter');
                
                // Update active button
                $filterButtons.removeClass('active');
                $(this).addClass('active');
                
                // Filter items
                if (filterValue === 'all') {
                    $grid.find('.custom-advanced-post').show();
                } else {
                    $grid.find('.custom-advanced-post').hide();
                    $grid.find('.custom-advanced-post[data-category="' + filterValue + '"]').show();
                }
            });
        }
        
        // Load more functionality
        if ($loadMoreButton.length) {
            $loadMoreButton.on('click', function() {
                const $button = $(this);
                const $hiddenPosts = $grid.find('.custom-advanced-post.hidden').slice(0, 3);
                
                if ($hiddenPosts.length) {
                    $hiddenPosts.removeClass('hidden').hide().fadeIn();
                    
                    // Hide button if no more posts
                    if ($grid.find('.custom-advanced-post.hidden').length === 0) {
                        $button.hide();
                    }
                }
            });
        }
        
        console.log('Advanced Post Grid Widget Initialized');
    }

    /**
     * Initialize Creative Buttons Widget
     */
    function initCreativeButtonsWidget($scope) {
        // Any button specific initialization code
        const $button = $scope.find('.custom-button');
        
        if ($button.length && $button.hasClass('elementor-animation-')) {
            $button.hover(
                function() {
                    $(this).addClass('elementor-animated');
                },
                function() {
                    $(this).removeClass('elementor-animated');
                }
            );
        }
        
        console.log('Creative Buttons Widget Initialized');
    }

    /**
     * Initialize Interactive Testimonials Widget
     */
    function initInteractiveTestimonialsWidget($scope) {
        const $carousel = $scope.find('.custom-testimonials-carousel');
        
        if ($carousel.length) {
            // Get carousel settings
            const settings = $carousel.data('settings') || {};
            const defaults = {
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 3000,
                arrows: true,
                dots: true,
                pauseOnHover: true,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 1,
                        }
                    }
                ]
            };
            
            // Merge defaults with settings
            const carouselSettings = $.extend({}, defaults, settings);
            
            // Simple carousel functionality for demonstration
            // In a real implementation, you would use a library like Slick
            console.log('Testimonial carousel initialized with settings:', carouselSettings);
        }
        
        console.log('Interactive Testimonials Widget Initialized');
    }

    /**
     * Initialize Info Box Widget
     */
    function initInfoBoxWidget($scope) {
        // Any info box specific initialization code
        console.log('Info Box Widget Initialized');
    }

    /**
     * Initialize Modal Popup Widget
     */
    function initModalPopupWidget($scope) {
        const $modalWrapper = $scope.find('.custom-modal-wrapper');
        const modalId = $modalWrapper.find('[data-modal]').data('modal');
        const $modal = $('#' + modalId);
        const $modalOverlay = $modal.find('.custom-modal-overlay');
        const $closeButton = $modal.find('.custom-modal-close');
        const $modalContent = $modal.find('.custom-modal-content');
        const $modalTitle = $modal.find('.custom-modal-title');
        const triggerType = $modalWrapper.data('trigger-type') || 'button';
        
        // Ensure proper ARIA attributes on init
        const modalElement = $modal[0];
        const triggerElement = $modalWrapper.find('[data-modal]')[0];
        
        // Set ARIA attributes for the modal dialog
        if (modalElement) {
            a11yHelpers.setAriaAttributes(modalElement, {
                'role': 'dialog',
                'aria-modal': 'true',
                'aria-hidden': 'true',
                'aria-labelledby': $modalTitle.length ? $modalTitle.attr('id') || modalId + '-title' : '',
            });
            
            // Make sure the title has an ID for aria-labelledby
            if ($modalTitle.length && !$modalTitle.attr('id')) {
                $modalTitle.attr('id', modalId + '-title');
            }
        }
        
        // Set ARIA attributes for the trigger element
        if (triggerElement) {
            a11yHelpers.setAriaAttributes(triggerElement, {
                'aria-haspopup': 'dialog',
                'aria-expanded': 'false'
            });
        }
        
        // Add role to close button
        if ($closeButton.length) {
            $closeButton.attr('aria-label', 'Close modal');
        }
        
        // Open modal function with accessibility enhancements
        function openModal() {
            // Store the element that had focus before opening the modal
            $modal.data('lastFocus', document.activeElement);
            
            // Update ARIA attributes
            $modal.attr('aria-hidden', 'false');
            
            if (triggerElement) {
                $(triggerElement).attr('aria-expanded', 'true');
            }
            
            // Show the modal
            $modal.fadeIn(300, function() {
                // Trap focus inside modal
                if (modalElement) {
                    a11yHelpers.trapFocus(modalElement);
                }
                
                // Announce to screen readers
                a11yHelpers.announceToScreenReader('Dialog opened');
            });
            
            $('body').addClass('custom-modal-open');
        }
        
        // Close modal function with accessibility enhancements
        function closeModal() {
            // Update ARIA attributes
            $modal.attr('aria-hidden', 'true');
            
            if (triggerElement) {
                $(triggerElement).attr('aria-expanded', 'false');
            }
            
            // Hide the modal
            $modal.fadeOut(300, function() {
                // Announce to screen readers
                a11yHelpers.announceToScreenReader('Dialog closed');
                
                // Restore focus to the element that had focus before the modal was opened
                const lastFocus = $modal.data('lastFocus');
                if (lastFocus) {
                    lastFocus.focus();
                }
            });
            
            $('body').removeClass('custom-modal-open');
        }
        
        // Trigger click handler
        $modalWrapper.find('[data-modal]').on('click', function(e) {
            e.preventDefault();
            openModal();
        });
        
        // Ensure trigger is keyboard accessible
        $modalWrapper.find('[data-modal]').each(function() {
            const $trigger = $(this);
            
            // Make sure trigger is focusable
            if (!$trigger.is('a, button') && !$trigger.attr('tabindex')) {
                $trigger.attr('tabindex', '0');
                
                // Add keyboard event
                $trigger.on('keydown', function(e) {
                    // Enter or Space
                    if (e.key === 'Enter' || e.key === ' ' || e.keyCode === 13 || e.keyCode === 32) {
                        e.preventDefault();
                        openModal();
                    }
                });
            }
        });
        
        // Close button handler
        $closeButton.on('click', function() {
            closeModal();
        });
        
        // Make close button keyboard accessible
        $closeButton.attr('tabindex', '0').on('keydown', function(e) {
            // Enter or Space
            if (e.key === 'Enter' || e.key === ' ' || e.keyCode === 13 || e.keyCode === 32) {
                e.preventDefault();
                closeModal();
            }
        });
        
        // Close on overlay click
        $modalOverlay.on('click', function() {
            if ($modal.data('overlay-close') !== false) {
                closeModal();
            }
        });
        
        // Close on ESC key - improved implementation using a11yHelpers
        if (modalElement) {
            a11yHelpers.handleEscKey(modalElement, function() {
                if ($modal.is(':visible') && $modal.data('esc-close') !== false) {
                    closeModal();
                }
            });
        }
        
        // Stop propagation on modal content click
        $modalContent.on('click', function(e) {
            e.stopPropagation();
        });
        
        // Auto-open modal functionality
        if (triggerType === 'page_load') {
            const delay = $modalWrapper.data('delay') || 2000;
            const cookieName = 'modal_shown_' + modalId;
            const showOnce = $modalWrapper.data('show-once') || false;
            
            // Check if modal should be shown
            let shouldShowModal = true;
            
            if (showOnce && document.cookie.indexOf(cookieName) !== -1) {
                shouldShowModal = false;
            }
            
            if (shouldShowModal) {
                setTimeout(function() {
                    openModal();
                    
                    // Set cookie if needed
                    if (showOnce) {
                        const expiryDays = $modalWrapper.data('cookie-expiry') || 30;
                        const d = new Date();
                        d.setTime(d.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
                        document.cookie = cookieName + '=true; expires=' + d.toUTCString() + '; path=/';
                    }
                }, delay);
            }
        } else if (triggerType === 'exit_intent') {
            const cookieName = 'modal_shown_' + modalId;
            const showOnce = $modalWrapper.data('show-once') || false;
            
            // Check if modal should be shown
            let shouldShowModal = true;
            
            if (showOnce && document.cookie.indexOf(cookieName) !== -1) {
                shouldShowModal = false;
            }
            
            if (shouldShowModal) {
                $(document).on('mouseleave', function(e) {
                    if (e.clientY < 0) {
                        openModal();
                        
                        // Set cookie if needed
                        if (showOnce) {
                            const expiryDays = $modalWrapper.data('cookie-expiry') || 30;
                            const d = new Date();
                            d.setTime(d.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
                            document.cookie = cookieName + '=true; expires=' + d.toUTCString() + '; path=/';
                        }
                        
                        // Remove event listener
                        $(document).off('mouseleave');
                    }
                });
            }
        } else if (triggerType === 'scroll') {
            const scrollDepth = $modalWrapper.data('scroll-depth') || 50;
            const cookieName = 'modal_shown_' + modalId;
            const showOnce = $modalWrapper.data('show-once') || false;
            
            // Check if modal should be shown
            let shouldShowModal = true;
            
            if (showOnce && document.cookie.indexOf(cookieName) !== -1) {
                shouldShowModal = false;
            }
            
            if (shouldShowModal) {
                $(window).on('scroll', function() {
                    const scrollPercentage = 100 * $(window).scrollTop() / ($(document).height() - $(window).height());
                    
                    if (scrollPercentage > scrollDepth) {
                        openModal();
                        
                        // Set cookie if needed
                        if (showOnce) {
                            const expiryDays = $modalWrapper.data('cookie-expiry') || 30;
                            const d = new Date();
                            d.setTime(d.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
                            document.cookie = cookieName + '=true; expires=' + d.toUTCString() + '; path=/';
                        }
                        
                        // Remove event listener
                        $(window).off('scroll');
                    }
                });
            }
        }
        
        console.log('Modal Popup Widget Initialized');
    }

    /**
     * Initialize JetTabs Widget
     */
    function initJetTabsWidget($scope) {
        const $wrapper = $scope.find('.jet-tabs-wrapper');
        const $controls = $scope.find('.jet-tabs-control');
        const $contents = $scope.find('.jet-tabs-content');
        
        if ($wrapper.length) {
            // Get settings
            const settings = {
                activeTab: parseInt($wrapper.attr('data-active-tab')),
                showEffect: $wrapper.attr('data-show-effect'),
                accordion: $wrapper.attr('data-accordion') === 'true',
                accordionCollapse: $wrapper.attr('data-accordion-collapse-others') === 'true',
                accordionCollapsible: $wrapper.attr('data-accordion-collapsible') === 'true',
                autoSwitch: $wrapper.attr('data-auto-switch') === 'true',
                autoSwitchDelay: parseInt($wrapper.attr('data-auto-switch-delay')) || 3000
            };
            
            // Add ARIA attributes for accessibility
            $wrapper.attr({
                'role': 'tablist',
                'aria-orientation': settings.accordion ? 'vertical' : 'horizontal'
            });

            // Set up accessibility attributes for tabs
            $controls.each(function(i) {
                const $control = $(this);
                const $content = $contents.eq(i);
                const controlId = 'tab-control-' + $scope.data('id') + '-' + i;
                const contentId = 'tab-content-' + $scope.data('id') + '-' + i;
                
                // Set ARIA attributes for tab control
                $control.attr({
                    'id': controlId,
                    'role': 'tab',
                    'aria-selected': 'false',
                    'aria-controls': contentId,
                    'tabindex': '-1'
                });
                
                // Set ARIA attributes for tab content
                $content.attr({
                    'id': contentId,
                    'role': 'tabpanel',
                    'aria-labelledby': controlId,
                    'tabindex': '0',
                    'hidden': 'true'
                });
            });
            
            // Initialize active tab
            if (settings.activeTab >= 0) {
                activateTab(settings.activeTab);
            }
            
            // Tab click handler
            $controls.on('click', function() {
                const tabIndex = $(this).data('tab') - 1;
                
                if (settings.accordion) {
                    // Accordion mode
                    if ($(this).hasClass('active-tab')) {
                        // If collapsible, we can collapse the active tab
                        if (settings.accordionCollapsible) {
                            $controls.removeClass('active-tab');
                            $contents.removeClass('active-content');
                            
                            // Update ARIA attributes
                            $(this).attr({
                                'aria-selected': 'false',
                                'tabindex': '-1'
                            });
                            $contents.eq(tabIndex).attr('hidden', 'true');
                        }
                    } else {
                        // Collapse others if needed
                        if (settings.accordionCollapse) {
                            $controls.removeClass('active-tab').attr({
                                'aria-selected': 'false',
                                'tabindex': '-1'
                            });
                            $contents.removeClass('active-content').attr('hidden', 'true');
                        }
                        
                        // Activate clicked tab
                        $(this).addClass('active-tab').attr({
                            'aria-selected': 'true',
                            'tabindex': '0'
                        });
                        $contents.eq(tabIndex).addClass('active-content').removeAttr('hidden');
                    }
                } else {
                    // Normal tab mode
                    activateTab(tabIndex);
                }
                
                // Focus the tab control for keyboard users
                $(this).focus();
            });
            
            // Keyboard navigation
            $controls.on('keydown', function(e) {
                const $current = $(this);
                let $target;
                
                // Based on the arrow key pressed, determine which tab should be focused
                switch(e.keyCode) {
                    case 37: // Left arrow
                    case 38: // Up arrow
                        e.preventDefault();
                        $target = $current.prev('.jet-tabs-control');
                        if (!$target.length) {
                            $target = $controls.last(); // Wrap around to the last tab
                        }
                        break;
                    case 39: // Right arrow
                    case 40: // Down arrow
                        e.preventDefault();
                        $target = $current.next('.jet-tabs-control');
                        if (!$target.length) {
                            $target = $controls.first(); // Wrap around to the first tab
                        }
                        break;
                    case 36: // Home key
                        e.preventDefault();
                        $target = $controls.first();
                        break;
                    case 35: // End key
                        e.preventDefault();
                        $target = $controls.last();
                        break;
                    case 32: // Space bar
                    case 13: // Enter key
                        e.preventDefault();
                        $current.click(); // Activate the current tab
                        return;
                    default:
                        return; // Do nothing for other keys
                }
                
                // Focus the target tab
                $target.focus();
            });
            
            // Auto switch functionality
            if (settings.autoSwitch && !settings.accordion && settings.activeTab >= 0) {
                let autoSwitchInterval = setInterval(function() {
                    let nextTab = (settings.activeTab + 1) % $controls.length;
                    activateTab(nextTab);
                }, settings.autoSwitchDelay);
                
                // Pause on hover or focus for accessibility
                $wrapper.hover(
                    function() {
                        clearInterval(autoSwitchInterval);
                    },
                    function() {
                        autoSwitchInterval = setInterval(function() {
                            let nextTab = (settings.activeTab + 1) % $controls.length;
                            activateTab(nextTab);
                        }, settings.autoSwitchDelay);
                    }
                );
                
                // Also pause autoplay when keyboard focused
                $wrapper.on('focusin', function() {
                    clearInterval(autoSwitchInterval);
                }).on('focusout', function() {
                    // Only restart if still set to autoSwitch
                    if (settings.autoSwitch) {
                        autoSwitchInterval = setInterval(function() {
                            let nextTab = (settings.activeTab + 1) % $controls.length;
                            activateTab(nextTab);
                        }, settings.autoSwitchDelay);
                    }
                });
            }
            
            // Activate tab function
            function activateTab(index) {
                settings.activeTab = index;
                
                // Update controls and ARIA attributes
                $controls.removeClass('active-tab')
                    .attr({
                        'aria-selected': 'false',
                        'tabindex': '-1'
                    });
                
                $controls.eq(index)
                    .addClass('active-tab')
                    .attr({
                        'aria-selected': 'true',
                        'tabindex': '0'
                    });
                
                // Update content areas and ARIA attributes
                $contents.removeClass('active-content')
                    .attr('hidden', 'true');
                
                $contents.eq(index)
                    .addClass('active-content')
                    .removeAttr('hidden');
                
                // Update wrapper data
                $wrapper.attr('data-active-tab', index);
                
                // Announce tab change to screen readers
                if (window.SR) {
                    window.SR.announce('Tab changed to: ' + $controls.eq(index).text());
                }
            }
        }
        
        console.log('JetTabs Widget Initialized with Accessibility Features');
    }

})(jQuery);