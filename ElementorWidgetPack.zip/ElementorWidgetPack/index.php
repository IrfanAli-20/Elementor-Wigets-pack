<?php
/**
 * Plugin Tester Page
 */

// Basic header
echo '<!DOCTYPE html>';
echo '<html lang="en">';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '<title>Custom Elementor Widgets Plugin</title>';
echo '<style>';
echo 'body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 1200px; margin: 0 auto; padding: 20px; }';
echo 'h1, h2, h3 { color: #2c3e50; }';
echo 'h1 { border-bottom: 2px solid #3498db; padding-bottom: 10px; }';
echo 'table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }';
echo 'th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }';
echo 'th { background-color: #f2f2f2; }';
echo 'tr:nth-child(even) { background-color: #f9f9f9; }';
echo '.card { border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin-bottom: 20px; background-color: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }';
echo '.widget-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }';
echo '.widget-card { border: 1px solid #ddd; border-radius: 8px; padding: 20px; background-color: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }';
echo '.widget-card h3 { margin-top: 0; color: #3498db; }';
echo '.widget-icon { font-size: 24px; margin-bottom: 15px; color: #3498db; }';
echo '.tag { display: inline-block; background-color: #e0f7fa; color: #0097a7; border-radius: 4px; padding: 3px 8px; margin-right: 5px; font-size: 12px; }';
echo '</style>';
echo '</head>';
echo '<body>';

// Page header
echo '<h1>Custom Elementor Widgets Plugin</h1>';
echo '<div class="card">';
echo '<h2>Plugin Information</h2>';
echo '<p>This plugin provides 10 custom widgets for Elementor page builder. It is designed to be modular, lightweight, and follows WordPress coding standards.</p>';
echo '</div>';

// Display plugin structure
echo '<div class="card">';
echo '<h2>Plugin Structure</h2>';

// Function to recursively list directory contents
function listDirectory($dir, $baseDir, $indent = 0) {
    $files = scandir($dir);
    
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') {
            continue;
        }
        
        $path = $dir . '/' . $file;
        $relativePath = str_replace($baseDir . '/', '', $path);
        
        if (is_dir($path)) {
            echo '<div style="margin-left: ' . ($indent * 20) . 'px;"><strong>📁 ' . htmlspecialchars($file) . '/</strong></div>';
            listDirectory($path, $baseDir, $indent + 1);
        } else {
            echo '<div style="margin-left: ' . ($indent * 20) . 'px;">📄 ' . htmlspecialchars($file) . '</div>';
        }
    }
}

echo '<div style="border: 1px solid #ddd; border-radius: 4px; padding: 15px; background-color: #f9f9f9; margin-top: 10px;">';
echo '<strong>📁 custom-elementor-widgets/</strong>';
listDirectory('./custom-elementor-widgets', '.');
echo '</div>';
echo '</div>';

// Display widgets information
echo '<div class="card">';
echo '<h2>Available Widgets</h2>';
echo '<div class="widget-grid">';

// Array of widgets
$widgets = [
    [
        'name' => 'Posts Widget',
        'icon' => '📝',
        'description' => 'Display posts in various layouts with customizable options.',
        'tags' => ['Posts', 'Blog', 'Content']
    ],
    [
        'name' => 'Forms Widget',
        'icon' => '📋',
        'description' => 'Create custom forms with various field types and styling options.',
        'tags' => ['Form', 'Contact', 'Input']
    ],
    [
        'name' => 'Call to Action Widget',
        'icon' => '🔊',
        'description' => 'Create eye-catching call-to-action sections with buttons and effects.',
        'tags' => ['CTA', 'Button', 'Action']
    ],
    [
        'name' => 'Slides Widget',
        'icon' => '🖼️',
        'description' => 'Create beautiful slideshows with various transition effects.',
        'tags' => ['Slider', 'Carousel', 'Gallery']
    ],
    [
        'name' => 'Advanced Post Grid Widget',
        'icon' => '📰',
        'description' => 'Display posts in a responsive grid with advanced filtering options.',
        'tags' => ['Grid', 'Posts', 'Filter']
    ],
    [
        'name' => 'Creative Buttons Widget',
        'icon' => '🔘',
        'description' => 'Add stylish buttons with hover effects and animations.',
        'tags' => ['Button', 'Link', 'Action']
    ],
    [
        'name' => 'Interactive Testimonials Widget',
        'icon' => '💬',
        'description' => 'Showcase customer testimonials with interactive elements.',
        'tags' => ['Testimonial', 'Review', 'Feedback']
    ],
    [
        'name' => 'Info Box Widget',
        'icon' => '📦',
        'description' => 'Display information in styled boxes with icons and animations.',
        'tags' => ['Info', 'Box', 'Feature']
    ],
    [
        'name' => 'Modal Popup Widget',
        'icon' => '🔍',
        'description' => 'Create modal popups with various trigger options and effects.',
        'tags' => ['Modal', 'Popup', 'Lightbox']
    ],
    [
        'name' => 'JetTabs Widget',
        'icon' => '📑',
        'description' => 'Create tabbed content areas with various styling options.',
        'tags' => ['Tabs', 'Toggle', 'Content']
    ],
];

// Loop through and display widgets
foreach ($widgets as $widget) {
    echo '<div class="widget-card">';
    echo '<div class="widget-icon">' . $widget['icon'] . '</div>';
    echo '<h3>' . htmlspecialchars($widget['name']) . '</h3>';
    echo '<p>' . htmlspecialchars($widget['description']) . '</p>';
    echo '<div>';
    foreach ($widget['tags'] as $tag) {
        echo '<span class="tag">' . htmlspecialchars($tag) . '</span>';
    }
    echo '</div>';
    echo '</div>';
}

echo '</div>';
echo '</div>';

// Installation instructions
echo '<div class="card">';
echo '<h2>Installation Instructions</h2>';
echo '<ol>';
echo '<li>Download the plugin ZIP file: <strong>dist/custom-elementor-widgets.zip</strong></li>';
echo '<li>Log in to your WordPress admin dashboard</li>';
echo '<li>Navigate to Plugins > Add New</li>';
echo '<li>Click the "Upload Plugin" button at the top of the page</li>';
echo '<li>Choose the downloaded ZIP file and click "Install Now"</li>';
echo '<li>After installation, click "Activate Plugin"</li>';
echo '<li>The custom widgets will now be available in the Elementor editor</li>';
echo '</ol>';
echo '</div>';

// Footer
echo '<div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #777;">';
echo 'Custom Elementor Widgets Plugin v1.0.0';
echo '</div>';

echo '</body>';
echo '</html>';